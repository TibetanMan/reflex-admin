from datetime import date, datetime
import asyncio

from services.order_export import (
    ExportParams,
    build_export_filename,
    estimate_mock_total_records,
    iter_mock_order_chunks,
    validate_export_params,
)


def test_validate_export_params_success():
    params = validate_export_params(
        bot_name="Main Bot",
        date_from="2026-01-01",
        date_to="2026-01-31",
    )

    assert params == ExportParams(
        bot_name="Main Bot",
        date_from=date(2026, 1, 1),
        date_to=date(2026, 1, 31),
    )


def test_validate_export_params_raises_for_invalid_range():
    try:
        validate_export_params(
            bot_name="Main Bot",
            date_from="2026-02-01",
            date_to="2026-01-01",
        )
    except ValueError as exc:
        assert "date_to" in str(exc)
    else:
        raise AssertionError("expected ValueError for reversed date range")


def test_estimate_mock_total_records_has_reasonable_floor_and_growth():
    one_day = estimate_mock_total_records(
        date_from=date(2026, 1, 1),
        date_to=date(2026, 1, 1),
    )
    thirty_days = estimate_mock_total_records(
        date_from=date(2026, 1, 1),
        date_to=date(2026, 1, 30),
    )

    assert one_day >= 100
    assert thirty_days > one_day


def test_build_export_filename_sanitizes_bot_name():
    name = build_export_filename(
        bot_name="Main/Bot #1",
        now=datetime(2026, 2, 8, 18, 30, 0),
    )

    assert name.startswith("orders_main_bot_1_20260208_183000")
    assert name.endswith(".csv")


def test_iter_mock_order_chunks_streams_expected_sizes_and_schema():
    params = ExportParams(
        bot_name="Main Bot",
        date_from=date(2026, 1, 1),
        date_to=date(2026, 1, 7),
    )

    async def _collect():
        sizes = []
        first_row_keys = set()

        async for chunk in iter_mock_order_chunks(
            params=params,
            total_records=1200,
            chunk_size=500,
            sleep_seconds=0,
        ):
            sizes.append(len(chunk))
            if chunk and not first_row_keys:
                first_row_keys = set(chunk[0].keys())

        return sizes, first_row_keys

    sizes, first_row_keys = asyncio.run(_collect())

    assert sizes == [500, 500, 200]
    assert {
        "order_no",
        "bot_name",
        "username",
        "telegram_id",
        "amount",
        "status",
        "created_at",
    }.issubset(first_row_keys)
