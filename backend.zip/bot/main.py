"""Bot 主入口"""

import asyncio
import logging
from aiogram import Bot, Dispatcher
from aiogram.enums import ParseMode
from aiogram.client.default import DefaultBotProperties

from shared.config import settings
from .handlers import start_router, menu_router

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger(__name__)


async def main():
    """Bot 主函数"""
    
    if not settings.bot_token:
        logger.error("BOT_TOKEN 未配置，请在 .env 文件中设置")
        return
    
    # 创建 Bot 实例
    bot = Bot(
        token=settings.bot_token,
        default=DefaultBotProperties(parse_mode=ParseMode.MARKDOWN)
    )
    
    # 创建调度器
    dp = Dispatcher()
    
    # 注册路由
    dp.include_router(start_router)
    dp.include_router(menu_router)
    
    logger.info("Bot 启动中...")
    
    try:
        # 开始轮询
        await dp.start_polling(bot)
    finally:
        await bot.session.close()


if __name__ == "__main__":
    asyncio.run(main())
