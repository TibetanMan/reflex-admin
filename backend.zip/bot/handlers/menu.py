"""菜单处理"""

from aiogram import Router, F
from aiogram.types import Message, ReplyKeyboardMarkup, KeyboardButton

router = Router(name="menu")


def get_main_menu() -> ReplyKeyboardMarkup:
    """获取主菜单键盘"""
    keyboard = [
        [
            KeyboardButton(text="🛒 全资库"),
            KeyboardButton(text="📦 裸资库"),
            KeyboardButton(text="🔥 特价库"),
        ],
        [
            KeyboardButton(text="🏪 商家基地"),
            KeyboardButton(text="🔍 卡头查询"),
            KeyboardButton(text="📋 库存文件"),
        ],
        [
            KeyboardButton(text="💰 充值"),
            KeyboardButton(text="💵 余额查询"),
            KeyboardButton(text="🛍️ 购物车"),
        ],
        [
            KeyboardButton(text="📜 订单记录"),
            KeyboardButton(text="🌐 English"),
        ],
    ]
    
    return ReplyKeyboardMarkup(
        keyboard=keyboard,
        resize_keyboard=True,
        is_persistent=True,
    )


@router.message(F.text == "🛒 全资库")
async def handle_full_info(message: Message):
    """处理全资库按钮"""
    await message.answer(
        "📦 **全资库分类**\n\n请选择国家/地区:",
        parse_mode="Markdown"
    )


@router.message(F.text == "📦 裸资库")
async def handle_basic_info(message: Message):
    """处理裸资库按钮"""
    await message.answer(
        "📦 **裸资库分类**\n\n请选择国家/地区:",
        parse_mode="Markdown"
    )


@router.message(F.text == "🔥 特价库")
async def handle_special(message: Message):
    """处理特价库按钮"""
    await message.answer(
        "🔥 **特价商品**\n\n限时优惠，库存有限!",
        parse_mode="Markdown"
    )


@router.message(F.text == "💰 充值")
async def handle_deposit(message: Message):
    """处理充值按钮"""
    await message.answer(
        "💰 **USDT 充值**\n\n请选择充值方式:\n\n• USDT (TRC20)",
        parse_mode="Markdown"
    )


@router.message(F.text == "💵 余额查询")
async def handle_balance(message: Message):
    """处理余额查询按钮"""
    await message.answer(
        f"💵 **账户余额**\n\n"
        f"可用余额: `0.00 USDT`\n"
        f"累计充值: `0.00 USDT`\n"
        f"累计消费: `0.00 USDT`",
        parse_mode="Markdown"
    )


@router.message(F.text == "🛍️ 购物车")
async def handle_cart(message: Message):
    """处理购物车按钮"""
    await message.answer(
        "🛍️ **购物车**\n\n购物车为空\n\n浏览商品添加到购物车后即可结算",
        parse_mode="Markdown"
    )


@router.message(F.text == "🔍 卡头查询")
async def handle_bin_search(message: Message):
    """处理卡头查询按钮"""
    await message.answer(
        "🔍 **卡头查询**\n\n请输入要查询的 BIN 码 (卡号前6位):\n\n例如: `440066`",
        parse_mode="Markdown"
    )


@router.message(F.text == "🏪 商家基地")
async def handle_merchant(message: Message):
    """处理商家基地按钮"""
    await message.answer(
        "🏪 **商家基地**\n\n入驻商家列表:",
        parse_mode="Markdown"
    )


@router.message(F.text == "📋 库存文件")
async def handle_stock_file(message: Message):
    """处理库存文件按钮"""
    await message.answer(
        "📋 **库存文件下载**\n\n正在生成库存清单...",
        parse_mode="Markdown"
    )


@router.message(F.text == "📜 订单记录")
async def handle_orders(message: Message):
    """处理订单记录按钮"""
    await message.answer(
        "📜 **订单记录**\n\n暂无订单记录",
        parse_mode="Markdown"
    )


@router.message(F.text == "🌐 English")
async def handle_language(message: Message):
    """处理语言切换按钮"""
    await message.answer(
        "🌐 Language switched to English\n\nNote: Full English support coming soon.",
        parse_mode="Markdown"
    )
