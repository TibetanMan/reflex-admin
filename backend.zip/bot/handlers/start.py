"""/start 命令处理"""

from aiogram import Router, F
from aiogram.types import Message
from aiogram.filters import Command, CommandStart

router = Router(name="start")


@router.message(CommandStart())
async def cmd_start(message: Message):
    """处理 /start 命令"""
    user = message.from_user
    
    welcome_text = f"""
🎉 **欢迎使用数字商品自动售卖平台**

👤 **用户信息**
├ ID: `{user.id}`
├ 用户名: @{user.username or '未设置'}
└ 余额: 0.00 USDT

📦 **快速开始**
使用下方菜单浏览商品，充值后即可购买

💬 **联系客服**
如有问题请联系管理员
    """
    
    await message.answer(
        welcome_text,
        parse_mode="Markdown"
    )


@router.message(Command("help"))
async def cmd_help(message: Message):
    """处理 /help 命令"""
    help_text = """
📖 **帮助文档**

**常用命令**
/start - 返回主菜单
/help - 查看帮助

**功能说明**
🛒 全资库 - 浏览完整信息商品
📦 裸资库 - 浏览基础信息商品
💰 充值 - USDT 充值
💵 余额 - 查看账户余额
🔍 搜索 - 按 BIN 码搜索

**购买流程**
1. 选择商品分类
2. 添加到购物车
3. 确认结算
4. 自动发货

如有问题请联系客服
    """
    
    await message.answer(help_text, parse_mode="Markdown")
