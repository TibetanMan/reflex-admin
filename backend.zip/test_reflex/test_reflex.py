﻿"""Bot Admin app entry."""

import reflex as rx

from .pages import (
    about,
    agents_page,
    bots_page,
    finance_page,
    index,
    inventory_page,
    login,
    orders_page,
    page_403,
    page_404,
    page_500,
    page_502,
    page_503,
    page_504,
    page_maintenance,
    page_offline,
    profile,
    settings,
    table_page,
    users_page,
)

app = rx.App(
    theme=rx.theme(
        appearance="dark",
        has_background=True,
        radius="medium",
        accent_color="indigo",
    ),
)

app.add_page(login, route="/login", title="Login | Bot Admin")
app.add_page(index, route="/", title="Dashboard | Bot Admin")

app.add_page(bots_page, route="/bots", title="Bots | Bot Admin")
app.add_page(inventory_page, route="/inventory", title="Inventory | Bot Admin")
app.add_page(orders_page, route="/orders", title="Orders | Bot Admin")
app.add_page(users_page, route="/users", title="Users | Bot Admin")
app.add_page(finance_page, route="/finance", title="Finance | Bot Admin")
app.add_page(agents_page, route="/agents", title="Agents | Bot Admin")

app.add_page(about, route="/about", title="About | Bot Admin")
app.add_page(profile, route="/profile", title="Profile | Bot Admin")
app.add_page(settings, route="/settings", title="Settings | Bot Admin")
app.add_page(table_page, route="/table", title="Table | Bot Admin")

app.add_page(page_403, route="/error/403", title="403 | Bot Admin")
app.add_page(page_500, route="/error/500", title="500 | Bot Admin")
app.add_page(page_502, route="/error/502", title="502 | Bot Admin")
app.add_page(page_503, route="/error/503", title="503 | Bot Admin")
app.add_page(page_504, route="/error/504", title="504 | Bot Admin")
app.add_page(page_maintenance, route="/maintenance", title="Maintenance | Bot Admin")
app.add_page(page_offline, route="/offline", title="Offline | Bot Admin")

app.add_page(page_404, route="/[[...splat]]", title="404 | Bot Admin")
