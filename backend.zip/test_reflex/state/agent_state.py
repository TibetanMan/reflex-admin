"""Agent management state."""

from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, List, Optional

import reflex as rx


def _mask_token(token: str) -> str:
    value = str(token).strip()
    if len(value) <= 14:
        return "****"
    return f"{value[:10]}...{value[-4:]}"


def _format_profit_rate_label(rate: float) -> str:
    return f"{rate * 100:.2f}%"


class AgentState(rx.State):
    """State for `/agents` page."""

    agents: List[Dict[str, Any]] = [
        {
            "id": 1,
            "name": "代理商A",
            "contact_telegram": "@agent_a",
            "contact_email": "agent-a@example.com",
            "bot_name": "代理A Bot",
            "bot_token": "7000011111:AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA",
            "masked_token": "7000011111...AAAA",
            "profit_rate": 0.12,
            "profit_rate_label": "12.00%",
            "usdt_address": "TXAgentA123...8QwP",
            "is_active": True,
            "is_verified": True,
            "total_bots": 1,
            "total_users": 456,
            "total_orders": 42,
            "total_profit": 982.40,
            "created_at": "2026-01-08 12:00",
        },
        {
            "id": 2,
            "name": "代理商B",
            "contact_telegram": "@agent_b",
            "contact_email": "agent-b@example.com",
            "bot_name": "代理B Bot",
            "bot_token": "7000022222:BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB",
            "masked_token": "7000022222...BBBB",
            "profit_rate": 0.10,
            "profit_rate_label": "10.00%",
            "usdt_address": "TXAgentB456...9ErT",
            "is_active": True,
            "is_verified": False,
            "total_bots": 1,
            "total_users": 289,
            "total_orders": 28,
            "total_profit": 513.75,
            "created_at": "2026-01-15 18:25",
        },
        {
            "id": 3,
            "name": "代理商C",
            "contact_telegram": "@agent_c",
            "contact_email": "agent-c@example.com",
            "bot_name": "未分配",
            "bot_token": "",
            "masked_token": "-",
            "profit_rate": 0.08,
            "profit_rate_label": "8.00%",
            "usdt_address": "",
            "is_active": False,
            "is_verified": False,
            "total_bots": 0,
            "total_users": 0,
            "total_orders": 0,
            "total_profit": 0.00,
            "created_at": "2026-02-01 09:10",
        },
    ]

    search_query: str = ""
    filter_status: str = "全部状态"

    show_create_modal: bool = False
    show_edit_modal: bool = False

    selected_agent_id: Optional[int] = None

    create_name: str = ""
    create_contact_telegram: str = ""
    create_contact_email: str = ""
    create_bot_name: str = ""
    create_bot_token: str = ""
    create_profit_rate: str = ""
    create_usdt_address: str = ""

    edit_name: str = ""
    edit_contact_telegram: str = ""
    edit_contact_email: str = ""
    edit_bot_name: str = ""
    edit_bot_token: str = ""
    edit_profit_rate: str = ""
    edit_usdt_address: str = ""
    edit_is_verified: bool = False

    def _find_agent(self, agent_id: int) -> Optional[Dict[str, Any]]:
        for agent in self.agents:
            if int(agent["id"]) == int(agent_id):
                return dict(agent)
        return None

    def _parse_profit_rate(self, value: str) -> Optional[float]:
        try:
            rate = float(value)
        except (ValueError, TypeError):
            return None
        if rate > 1:
            rate = rate / 100
        if rate < 0 or rate > 1:
            return None
        return round(rate, 4)

    def set_search_query(self, value: str):
        self.search_query = value

    def set_filter_status(self, value: str):
        self.filter_status = value

    def refresh_list(self):
        return rx.toast.info("代理列表已刷新", duration=1500)

    def open_create_modal(self):
        self.show_create_modal = True
        self.create_name = ""
        self.create_contact_telegram = ""
        self.create_contact_email = ""
        self.create_bot_name = ""
        self.create_bot_token = ""
        self.create_profit_rate = ""
        self.create_usdt_address = ""

    def close_create_modal(self):
        self.show_create_modal = False

    def handle_create_modal_change(self, is_open: bool):
        if not is_open:
            self.close_create_modal()

    def set_create_name(self, value: str):
        self.create_name = value

    def set_create_contact_telegram(self, value: str):
        self.create_contact_telegram = value

    def set_create_contact_email(self, value: str):
        self.create_contact_email = value

    def set_create_bot_name(self, value: str):
        self.create_bot_name = value

    def set_create_bot_token(self, value: str):
        self.create_bot_token = value

    def set_create_profit_rate(self, value: str):
        self.create_profit_rate = value

    def set_create_usdt_address(self, value: str):
        self.create_usdt_address = value

    def save_new_agent(self):
        name = self.create_name.strip()
        token = self.create_bot_token.strip()
        rate = self._parse_profit_rate(self.create_profit_rate.strip() or "0")

        if not name:
            return rx.toast.error("代理名称不能为空", duration=1800)
        if not token:
            return rx.toast.error("Bot Token 不能为空", duration=1800)
        if rate is None:
            return rx.toast.error("分润比例格式无效，支持 0-1 或 0-100", duration=2200)

        next_id = max((int(agent["id"]) for agent in self.agents), default=0) + 1
        now = datetime.now().strftime("%Y-%m-%d %H:%M")
        bot_name = self.create_bot_name.strip() or f"{name} Bot"

        new_agent = {
            "id": next_id,
            "name": name,
            "contact_telegram": self.create_contact_telegram.strip(),
            "contact_email": self.create_contact_email.strip(),
            "bot_name": bot_name,
            "bot_token": token,
            "masked_token": _mask_token(token),
            "profit_rate": rate,
            "profit_rate_label": _format_profit_rate_label(rate),
            "usdt_address": self.create_usdt_address.strip(),
            "is_active": True,
            "is_verified": False,
            "total_bots": 1,
            "total_users": 0,
            "total_orders": 0,
            "total_profit": 0.00,
            "created_at": now,
        }
        self.agents = [new_agent, *self.agents]
        self.close_create_modal()
        return rx.toast.success("代理已创建并分配 Bot", duration=2200)

    def open_edit_modal(self, agent_id: int):
        agent = self._find_agent(agent_id)
        if not agent:
            return rx.toast.error("代理不存在", duration=1500)

        self.selected_agent_id = agent_id
        self.edit_name = str(agent.get("name", ""))
        self.edit_contact_telegram = str(agent.get("contact_telegram", ""))
        self.edit_contact_email = str(agent.get("contact_email", ""))
        self.edit_bot_name = str(agent.get("bot_name", ""))
        self.edit_bot_token = str(agent.get("bot_token", ""))
        self.edit_profit_rate = f"{float(agent.get('profit_rate', 0)):.4f}"
        self.edit_usdt_address = str(agent.get("usdt_address", ""))
        self.edit_is_verified = bool(agent.get("is_verified", False))
        self.show_edit_modal = True

    def close_edit_modal(self):
        self.show_edit_modal = False
        self.selected_agent_id = None

    def handle_edit_modal_change(self, is_open: bool):
        if not is_open:
            self.close_edit_modal()

    def set_edit_name(self, value: str):
        self.edit_name = value

    def set_edit_contact_telegram(self, value: str):
        self.edit_contact_telegram = value

    def set_edit_contact_email(self, value: str):
        self.edit_contact_email = value

    def set_edit_bot_name(self, value: str):
        self.edit_bot_name = value

    def set_edit_bot_token(self, value: str):
        self.edit_bot_token = value

    def set_edit_profit_rate(self, value: str):
        self.edit_profit_rate = value

    def set_edit_usdt_address(self, value: str):
        self.edit_usdt_address = value

    def set_edit_is_verified(self, value: bool):
        self.edit_is_verified = value

    def save_edit_agent(self):
        if self.selected_agent_id is None:
            return rx.toast.error("未选择代理", duration=1500)

        name = self.edit_name.strip()
        token = self.edit_bot_token.strip()
        rate = self._parse_profit_rate(self.edit_profit_rate.strip() or "0")
        if not name:
            return rx.toast.error("代理名称不能为空", duration=1800)
        if not token:
            return rx.toast.error("Bot Token 不能为空", duration=1800)
        if rate is None:
            return rx.toast.error("分润比例格式无效，支持 0-1 或 0-100", duration=2200)

        updated: List[Dict[str, Any]] = []
        found = False
        for agent in self.agents:
            if int(agent["id"]) != int(self.selected_agent_id):
                updated.append(agent)
                continue

            found = True
            row = dict(agent)
            row["name"] = name
            row["contact_telegram"] = self.edit_contact_telegram.strip()
            row["contact_email"] = self.edit_contact_email.strip()
            row["bot_name"] = self.edit_bot_name.strip() or f"{name} Bot"
            row["bot_token"] = token
            row["masked_token"] = _mask_token(token)
            row["profit_rate"] = rate
            row["profit_rate_label"] = _format_profit_rate_label(rate)
            row["usdt_address"] = self.edit_usdt_address.strip()
            row["is_verified"] = bool(self.edit_is_verified)
            updated.append(row)

        if not found:
            return rx.toast.error("代理不存在", duration=1500)

        self.agents = updated
        self.close_edit_modal()
        return rx.toast.success("代理配置已更新", duration=2000)

    def toggle_agent_status(self, agent_id: int):
        updated: List[Dict[str, Any]] = []
        found = False
        is_active = False
        for agent in self.agents:
            if int(agent["id"]) != int(agent_id):
                updated.append(agent)
                continue

            found = True
            row = dict(agent)
            row["is_active"] = not bool(row.get("is_active", False))
            is_active = bool(row["is_active"])
            updated.append(row)

        if not found:
            return rx.toast.error("代理不存在", duration=1500)

        self.agents = updated
        return rx.toast.success("代理已启用" if is_active else "代理已停用", duration=1800)

    @rx.var
    def status_options(self) -> List[str]:
        return ["全部状态", "已启用", "已停用", "待认证", "已认证"]

    @rx.var
    def filtered_agents(self) -> List[Dict[str, Any]]:
        data = list(self.agents)

        query = self.search_query.strip().lower()
        if query:
            data = [
                item
                for item in data
                if query in str(item.get("name", "")).lower()
                or query in str(item.get("contact_telegram", "")).lower()
                or query in str(item.get("contact_email", "")).lower()
                or query in str(item.get("bot_name", "")).lower()
            ]

        if self.filter_status == "已启用":
            data = [item for item in data if bool(item.get("is_active", False))]
        elif self.filter_status == "已停用":
            data = [item for item in data if not bool(item.get("is_active", False))]
        elif self.filter_status == "待认证":
            data = [item for item in data if not bool(item.get("is_verified", False))]
        elif self.filter_status == "已认证":
            data = [item for item in data if bool(item.get("is_verified", False))]

        return sorted(data, key=lambda item: str(item.get("created_at", "")), reverse=True)

    @rx.var
    def total_agents(self) -> int:
        return len(self.agents)

    @rx.var
    def active_agents(self) -> int:
        return sum(1 for item in self.agents if bool(item.get("is_active", False)))

    @rx.var
    def verified_agents(self) -> int:
        return sum(1 for item in self.agents if bool(item.get("is_verified", False)))

    @rx.var
    def total_agent_profit(self) -> float:
        return round(sum(float(item.get("total_profit", 0)) for item in self.agents), 2)
