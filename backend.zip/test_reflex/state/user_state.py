"""用户管理状态"""

from __future__ import annotations

import asyncio
import csv
import re
import uuid
from datetime import datetime, timedelta
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from pathlib import Path
from typing import Any, Dict, List, Optional

import reflex as rx

from services.order_export import sanitize_csv_value


AMOUNT_INPUT_PATTERN = re.compile(r"^\d{0,10}(\.\d{0,2})?$")
MAX_BALANCE_ADJUST_AMOUNT = Decimal("10000000.00")


class UserState(rx.State):
    """用户管理状态"""

    users: List[Dict[str, Any]] = [
        {
            "id": 1,
            "telegram_id": "123456789",
            "username": "@user_alice",
            "name": "Alice",
            "balance": 125.50,
            "total_deposit": 500.00,
            "total_spent": 374.50,
            "orders": 15,
            "status": "active",
            "bot_sources": [
                {"bot_id": 1, "bot_name": "主站 Bot"},
                {"bot_id": 2, "bot_name": "代理A Bot"},
            ],
            "primary_bot": "主站 Bot",
            "created_at": "2024-01-20",
            "last_active": "2024-02-08 10:30",
            "deposit_records": [
                {
                    "record_no": "DEP20240208001",
                    "action": "充值",
                    "amount": 100.00,
                    "remark": "活动补贴",
                    "bot_name": "主站 Bot",
                    "created_at": "2024-02-08 10:00",
                },
            ],
            "purchase_records": [
                {
                    "order_no": "ORD20240208001",
                    "item": "US-VISA-Premium",
                    "amount": 25.00,
                    "status": "completed",
                    "bot_name": "主站 Bot",
                    "created_at": "2024-02-08 10:30",
                },
            ],
        },
        {
            "id": 2,
            "telegram_id": "234567890",
            "username": "@user_bob",
            "name": "Bob",
            "balance": 50.00,
            "total_deposit": 200.00,
            "total_spent": 150.00,
            "orders": 8,
            "status": "active",
            "bot_sources": [{"bot_id": 2, "bot_name": "代理A Bot"}],
            "primary_bot": "代理A Bot",
            "created_at": "2024-01-25",
            "last_active": "2024-02-07 15:45",
            "deposit_records": [
                {
                    "record_no": "DEP20240207002",
                    "action": "充值",
                    "amount": 50.00,
                    "remark": "手动补款",
                    "bot_name": "代理A Bot",
                    "created_at": "2024-02-07 12:00",
                },
            ],
            "purchase_records": [
                {
                    "order_no": "ORD20240208002",
                    "item": "UK-VISA-Basic",
                    "amount": 15.50,
                    "status": "completed",
                    "bot_name": "代理A Bot",
                    "created_at": "2024-02-08 10:05",
                },
            ],
        },
        {
            "id": 3,
            "telegram_id": "345678901",
            "username": "@user_charlie",
            "name": "Charlie",
            "balance": 0.00,
            "total_deposit": 100.00,
            "total_spent": 100.00,
            "orders": 5,
            "status": "banned",
            "bot_sources": [
                {"bot_id": 1, "bot_name": "主站 Bot"},
                {"bot_id": 3, "bot_name": "代理B Bot"},
            ],
            "primary_bot": "主站 Bot",
            "created_at": "2024-02-01",
            "last_active": "2024-02-05 09:20",
            "deposit_records": [],
            "purchase_records": [
                {
                    "order_no": "ORD20240201001",
                    "item": "CA-VISA-Sale",
                    "amount": 42.00,
                    "status": "refunded",
                    "bot_name": "主站 Bot",
                    "created_at": "2024-02-01 11:00",
                },
            ],
        },
        {
            "id": 4,
            "telegram_id": "456789012",
            "username": None,
            "name": "User_456789012",
            "balance": 75.25,
            "total_deposit": 150.00,
            "total_spent": 74.75,
            "orders": 3,
            "status": "active",
            "bot_sources": [{"bot_id": 3, "bot_name": "代理B Bot"}],
            "primary_bot": "代理B Bot",
            "created_at": "2024-02-05",
            "last_active": "2024-02-08 09:15",
            "deposit_records": [
                {
                    "record_no": "DEP20240205001",
                    "action": "充值",
                    "amount": 75.25,
                    "remark": "首次充值",
                    "bot_name": "代理B Bot",
                    "created_at": "2024-02-05 09:00",
                },
            ],
            "purchase_records": [],
        },
    ]

    # 分页
    current_page: int = 1
    page_size: int = 20
    page_size_options: List[int] = [20, 30, 40, 50]

    # 弹窗/抽屉控制
    show_detail_modal: bool = False
    show_balance_modal: bool = False
    show_balance_confirm_modal: bool = False
    show_export_modal: bool = False
    show_user_activity_drawer: bool = False

    # 选中用户
    selected_user_id: Optional[int] = None
    selected_user: Dict[str, Any] = {}
    selected_source_bot: str = ""

    # 余额操作
    balance_amount: str = ""
    balance_remark: str = ""
    balance_action: str = "充值"
    pending_balance_payload: Dict[str, Any] = {}
    last_balance_request_id: str = ""
    last_balance_request_payload: Dict[str, Any] = {}

    # 筛选
    search_query: str = ""
    filter_status: str = "全部状态"
    filter_bot: str = "全部 Bot"

    # 导出
    export_bot: str = "全部 Bot"
    export_date_from: str = ""
    export_date_to: str = ""
    is_exporting: bool = False
    export_progress: int = 0
    export_status: str = "idle"  # idle, processing, completed, failed
    export_message: str = ""
    export_file_url: str = ""
    export_file_name: str = ""
    export_total_records: int = 0
    export_processed_records: int = 0

    # ==================== Internal Helpers ====================

    def _sanitize_avatar_fallback(self, user: Dict[str, Any]) -> str:
        """从数据源层保证头像 fallback 只有一个字符。"""
        name = str(user.get("name") or "").strip()
        if name:
            return name[0].upper()
        username = str(user.get("username") or "").strip().lstrip("@")
        if username:
            return username[0].upper()
        telegram_id = str(user.get("telegram_id") or "").strip()
        if telegram_id:
            return telegram_id[0]
        return "#"

    def _normalize_bot_sources(self, user: Dict[str, Any]) -> List[Dict[str, Any]]:
        raw_sources = user.get("bot_sources")
        normalized: List[Dict[str, Any]] = []

        if isinstance(raw_sources, list):
            for source in raw_sources:
                if not isinstance(source, dict):
                    continue
                bot_name = str(source.get("bot_name") or "").strip()
                if not bot_name:
                    continue
                normalized.append(
                    {
                        "bot_id": int(source.get("bot_id") or 0),
                        "bot_name": bot_name,
                    }
                )

        if not normalized:
            from_bot = str(user.get("from_bot") or "").strip()
            if from_bot:
                normalized.append({"bot_id": 0, "bot_name": from_bot})

        return normalized

    def _normalize_user(self, user: Dict[str, Any]) -> Dict[str, Any]:
        data = dict(user)
        data["telegram_id"] = str(data.get("telegram_id") or "")
        data["balance_text"] = f"{float(data.get('balance', 0)):.2f}"
        data["total_deposit_text"] = f"{float(data.get('total_deposit', 0)):.2f}"
        data["avatar_fallback"] = self._sanitize_avatar_fallback(data)
        data["bot_sources"] = self._normalize_bot_sources(data)
        data["source_bots_label"] = " / ".join(
            [source["bot_name"] for source in data["bot_sources"]]
        )
        data["primary_bot"] = (
            str(data.get("primary_bot") or "").strip()
            or (data["bot_sources"][0]["bot_name"] if data["bot_sources"] else "-")
        )
        data["username"] = data.get("username")
        data["deposit_records"] = list(data.get("deposit_records", []))
        data["purchase_records"] = list(data.get("purchase_records", []))
        return data

    def _parse_yyyy_mm_dd(self, value: str) -> Optional[datetime]:
        try:
            return datetime.strptime(value, "%Y-%m-%d")
        except ValueError:
            return None

    def _parse_amount_decimal(self, value: str) -> Optional[Decimal]:
        try:
            amount = Decimal(value)
        except (InvalidOperation, ValueError):
            return None
        return amount.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)

    def _find_normalized_user_by_id(self, user_id: int) -> Optional[Dict[str, Any]]:
        for user in self.normalized_users:
            if int(user["id"]) == int(user_id):
                return user
        return None

    def _pick_default_source_bot(self, user: Dict[str, Any]) -> str:
        bot_sources = user.get("bot_sources", [])
        if bot_sources:
            return str(bot_sources[0]["bot_name"])
        return "-"

    # ==================== Generic ====================

    def refresh_list(self):
        return rx.toast.info("列表已刷新", duration=1500)

    # ==================== Copy ====================

    def copy_telegram_id(self, telegram_id: str):
        value = str(telegram_id).strip()
        if not value:
            return rx.toast.error("Telegram ID 为空", duration=1500)
        return [
            rx.set_clipboard(value),
            rx.toast.success("Telegram ID 已复制", duration=1500),
        ]

    def copy_username(self, username: str):
        value = str(username).strip()
        if not value or value == "-":
            return rx.toast.error("用户名为空，无法复制", duration=1500)
        return [
            rx.set_clipboard(value),
            rx.toast.success("用户名已复制", duration=1500),
        ]

    # ==================== Filters ====================

    def set_search_query(self, value: str):
        self.search_query = value
        self.current_page = 1

    def set_filter_status(self, value: str):
        self.filter_status = value
        self.current_page = 1

    def set_filter_bot(self, value: str):
        self.filter_bot = value
        self.current_page = 1

    # ==================== Pagination ====================

    def set_page_size(self, value: str):
        try:
            size = int(value)
        except ValueError:
            size = 20

        if size < 20:
            size = 20
        if size > 50:
            size = 50
        self.page_size = size
        self.current_page = 1

    def first_page(self):
        self.current_page = 1

    def prev_page(self):
        if self.current_page > 1:
            self.current_page -= 1

    def next_page(self):
        if self.current_page < self.total_pages:
            self.current_page += 1

    def last_page(self):
        self.current_page = self.total_pages

    # ==================== User Selection ====================

    def set_selected_source_bot(self, value: str):
        options = self.selected_user_bot_source_options
        if value in options:
            self.selected_source_bot = value
        elif options:
            self.selected_source_bot = options[0]
        else:
            self.selected_source_bot = "-"

    # ==================== Detail Modal ====================

    def open_detail_modal(self, user_id: int):
        user = self._find_normalized_user_by_id(user_id)
        if not user:
            return rx.toast.error("用户不存在或已删除", duration=2000)

        self.selected_user_id = user_id
        self.selected_user = user
        self.selected_source_bot = self._pick_default_source_bot(user)
        self.show_detail_modal = True

    def close_detail_modal(self):
        self.show_detail_modal = False
        self.selected_user_id = None
        self.selected_user = {}
        self.selected_source_bot = ""

    def handle_detail_modal_change(self, is_open: bool):
        if not is_open:
            self.close_detail_modal()

    # ==================== Activity Drawer ====================

    def open_user_activity_drawer(self, user_id: int):
        user = self._find_normalized_user_by_id(user_id)
        if not user:
            return rx.toast.error("用户不存在或已删除", duration=2000)

        self.selected_user_id = user_id
        self.selected_user = user
        self.selected_source_bot = self._pick_default_source_bot(user)
        self.show_user_activity_drawer = True

    def close_user_activity_drawer(self):
        self.show_user_activity_drawer = False
        self.selected_user_id = None
        self.selected_user = {}
        self.selected_source_bot = ""

    def handle_user_activity_drawer_change(self, is_open: bool):
        if not is_open:
            self.close_user_activity_drawer()

    # ==================== Ban / Unban ====================

    def toggle_ban(self, user_id: int):
        updated_users: List[Dict[str, Any]] = []
        found = False
        will_ban = False

        for user in self.users:
            if int(user["id"]) != int(user_id):
                updated_users.append(user)
                continue

            found = True
            next_user = dict(user)
            will_ban = next_user.get("status") != "banned"
            next_user["status"] = "banned" if will_ban else "active"
            updated_users.append(next_user)

        if not found:
            return rx.toast.error("用户不存在或已删除", duration=2000)

        self.users = updated_users
        return rx.toast.success("用户已封禁" if will_ban else "用户已解封", duration=2000)

    # ==================== Balance ====================

    def open_balance_modal(self, user_id: int):
        user = self._find_normalized_user_by_id(user_id)
        if not user:
            return rx.toast.error("用户不存在或已删除", duration=2000)

        self.selected_user_id = user_id
        self.selected_user = user
        self.selected_source_bot = self._pick_default_source_bot(user)
        self.balance_amount = ""
        self.balance_remark = ""
        self.balance_action = "充值"
        self.pending_balance_payload = {}
        self.show_balance_modal = True

    def close_balance_modal(self):
        self.show_balance_modal = False
        self.selected_user_id = None
        self.selected_user = {}
        self.selected_source_bot = ""
        self.balance_amount = ""
        self.balance_remark = ""
        self.balance_action = "充值"
        self.pending_balance_payload = {}
        self.show_balance_confirm_modal = False

    def handle_balance_modal_change(self, is_open: bool):
        if not is_open:
            self.close_balance_modal()

    def set_balance_action(self, value: str):
        self.balance_action = value if value in ("充值", "扣款") else "充值"

    def set_balance_amount(self, value: str):
        sanitized = str(value).strip().replace(",", "")
        if sanitized == "":
            self.balance_amount = ""
            return
        if any(ch in sanitized for ch in ("+", "-", "e", "E")):
            return
        if AMOUNT_INPUT_PATTERN.fullmatch(sanitized):
            self.balance_amount = sanitized

    def normalize_balance_amount(self):
        if not self.balance_amount or self.balance_amount == ".":
            return
        amount = self._parse_amount_decimal(self.balance_amount)
        if amount is None:
            return
        if amount < 0:
            return
        self.balance_amount = f"{amount:.2f}"

    def set_balance_remark(self, value: str):
        self.balance_remark = value

    def request_balance_confirmation(self):
        if self.selected_user_id is None or not self.selected_user:
            return rx.toast.error("请选择要操作的用户", duration=2000)

        self.normalize_balance_amount()

        amount_text = self.balance_amount.strip()
        remark_text = self.balance_remark.strip()
        if not amount_text:
            return rx.toast.error("金额不能为空", duration=2000)
        if not remark_text:
            return rx.toast.error("备注不能为空", duration=2000)

        amount = self._parse_amount_decimal(amount_text)
        if amount is None:
            return rx.toast.error("金额格式非法，仅支持两位小数", duration=2000)
        if amount <= 0:
            return rx.toast.error("金额必须大于 0", duration=2000)
        if amount > MAX_BALANCE_ADJUST_AMOUNT:
            return rx.toast.error("金额过大，请拆分后操作", duration=2000)

        current_balance = Decimal(str(self.selected_user.get("balance", 0))).quantize(
            Decimal("0.01"), rounding=ROUND_HALF_UP
        )
        if self.balance_action == "扣款" and amount > current_balance:
            return rx.toast.error("扣款金额不能大于当前余额", duration=2000)

        source_bot = self.selected_source_bot or self._pick_default_source_bot(self.selected_user)
        self.balance_amount = f"{amount:.2f}"
        self.pending_balance_payload = {
            "request_id": uuid.uuid4().hex,
            "user_id": int(self.selected_user_id),
            "telegram_id": str(self.selected_user.get("telegram_id", "")),
            "action": self.balance_action,
            "amount": f"{amount:.2f}",
            "remark": remark_text,
            "source_bot": source_bot,
            "requested_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        }
        self.show_balance_confirm_modal = True

    def close_balance_confirm_modal(self):
        self.show_balance_confirm_modal = False
        self.pending_balance_payload = {}

    def handle_balance_confirm_modal_change(self, is_open: bool):
        if not is_open:
            self.close_balance_confirm_modal()

    def confirm_balance_adjustment(self):
        if not self.pending_balance_payload:
            return rx.toast.error("未找到待确认的余额请求", duration=2000)

        payload = dict(self.pending_balance_payload)
        amount = self._parse_amount_decimal(str(payload.get("amount", "")))
        if amount is None:
            return rx.toast.error("金额格式错误，请重新填写", duration=2000)

        target_user_id = int(payload["user_id"])
        updated_users: List[Dict[str, Any]] = []
        found = False

        for user in self.users:
            if int(user["id"]) != target_user_id:
                updated_users.append(user)
                continue

            found = True
            next_user = dict(user)

            current_balance = Decimal(str(next_user.get("balance", 0))).quantize(
                Decimal("0.01"), rounding=ROUND_HALF_UP
            )
            total_deposit = Decimal(str(next_user.get("total_deposit", 0))).quantize(
                Decimal("0.01"), rounding=ROUND_HALF_UP
            )

            if payload["action"] == "扣款":
                next_balance = current_balance - amount
            else:
                next_balance = current_balance + amount
                total_deposit = total_deposit + amount

            next_user["balance"] = float(next_balance)
            next_user["total_deposit"] = float(total_deposit)

            records = list(next_user.get("deposit_records", []))
            records.append(
                {
                    "record_no": f"DEP{datetime.now():%Y%m%d%H%M%S}",
                    "action": payload["action"],
                    "amount": float(amount),
                    "remark": payload["remark"],
                    "bot_name": payload["source_bot"],
                    "created_at": payload["requested_at"],
                }
            )
            next_user["deposit_records"] = records
            updated_users.append(next_user)

        if not found:
            return rx.toast.error("用户不存在或已删除", duration=2000)

        self.users = updated_users
        self.last_balance_request_id = str(payload["request_id"])
        self.last_balance_request_payload = payload
        self.close_balance_modal()

        return [
            rx.toast.success("余额调整成功，正在推送后端", duration=2200),
            type(self).push_balance_adjustment_to_backend,
        ]

    @rx.event(background=True)
    async def push_balance_adjustment_to_backend(self):
        """后端推送占位：后续替换为真实 API 调用。"""
        await asyncio.sleep(0.15)
        async with self:
            request_id = self.last_balance_request_id
            has_payload = bool(self.last_balance_request_payload)
        if request_id and has_payload:
            return rx.toast.info(f"已推送余额变更请求: {request_id[:8]}", duration=2200)

    # ==================== Export ====================

    def open_export_modal(self):
        self.show_export_modal = True
        self.export_status = "idle"
        self.export_message = ""
        self.export_progress = 0
        self.export_file_name = ""
        self.export_file_url = ""
        self.export_total_records = 0
        self.export_processed_records = 0
        self.export_bot = "全部 Bot"

        today = datetime.now()
        if not self.export_date_to:
            self.export_date_to = today.strftime("%Y-%m-%d")
        if not self.export_date_from:
            self.export_date_from = (today - timedelta(days=30)).strftime("%Y-%m-%d")

    def close_export_modal(self):
        self.show_export_modal = False

    def handle_export_modal_change(self, is_open: bool):
        if not is_open:
            self.close_export_modal()

    def set_export_bot(self, value: str):
        if value in self.export_bot_options:
            self.export_bot = value

    def set_export_date_from(self, value: str):
        self.export_date_from = value

    def set_export_date_to(self, value: str):
        self.export_date_to = value

    def export_users(self):
        if self.is_exporting:
            return rx.toast.info("导出任务正在执行中", duration=2000)

        start = self._parse_yyyy_mm_dd(self.export_date_from)
        end = self._parse_yyyy_mm_dd(self.export_date_to)
        if not start or not end:
            return rx.toast.error("日期格式不正确，请使用 YYYY-MM-DD", duration=2500)
        if end < start:
            return rx.toast.error("结束日期不能早于开始日期", duration=2500)

        self.is_exporting = True
        self.export_status = "processing"
        self.export_progress = 10
        self.export_message = "正在筛选用户数据..."

        export_users: List[Dict[str, Any]] = []
        for user in self.normalized_users:
            created_at = str(user.get("created_at", ""))[:10]
            created_dt = self._parse_yyyy_mm_dd(created_at)
            if not created_dt:
                continue
            if created_dt < start or created_dt > end:
                continue

            if self.export_bot != "全部 Bot":
                source_names = [src["bot_name"] for src in user.get("bot_sources", [])]
                if self.export_bot not in source_names:
                    continue

            export_users.append(user)

        self.export_total_records = len(export_users)
        self.export_processed_records = 0
        self.export_progress = 45
        self.export_message = "正在生成导出文件..."

        exports_dir = Path("uploaded_files") / "exports"
        exports_dir.mkdir(parents=True, exist_ok=True)

        safe_bot = re.sub(r"[^a-zA-Z0-9]+", "_", self.export_bot.strip().lower()).strip("_")
        if not safe_bot:
            safe_bot = "all_bots"
        file_name = f"users_{safe_bot}_{datetime.now():%Y%m%d_%H%M%S}.csv"
        file_path = exports_dir / file_name

        headers = [
            "telegram_id",
            "name",
            "username",
            "status",
            "balance",
            "total_deposit",
            "total_spent",
            "orders",
            "source_bots",
            "primary_bot",
            "created_at",
            "last_active",
        ]

        with file_path.open("w", encoding="utf-8-sig", newline="") as csv_file:
            writer = csv.DictWriter(csv_file, fieldnames=headers)
            writer.writeheader()
            for index, user in enumerate(export_users):
                source_bots = " | ".join(
                    [src["bot_name"] for src in user.get("bot_sources", [])]
                )
                writer.writerow(
                    {
                        "telegram_id": sanitize_csv_value(user.get("telegram_id", "")),
                        "name": sanitize_csv_value(user.get("name", "")),
                        "username": sanitize_csv_value(user.get("username") or ""),
                        "status": sanitize_csv_value(user.get("status", "")),
                        "balance": sanitize_csv_value(f"{float(user.get('balance', 0)):.2f}"),
                        "total_deposit": sanitize_csv_value(
                            f"{float(user.get('total_deposit', 0)):.2f}"
                        ),
                        "total_spent": sanitize_csv_value(f"{float(user.get('total_spent', 0)):.2f}"),
                        "orders": sanitize_csv_value(user.get("orders", 0)),
                        "source_bots": sanitize_csv_value(source_bots),
                        "primary_bot": sanitize_csv_value(user.get("primary_bot", "")),
                        "created_at": sanitize_csv_value(user.get("created_at", "")),
                        "last_active": sanitize_csv_value(user.get("last_active", "")),
                    }
                )
                self.export_processed_records = index + 1

        self.export_file_name = file_name
        self.export_file_url = str(file_path)
        self.export_status = "completed"
        self.export_progress = 100
        self.export_message = "导出完成，可直接下载。"
        self.is_exporting = False

        return rx.toast.success(
            f"导出完成，共 {self.export_total_records} 条用户记录",
            duration=3000,
        )

    def download_export_file(self):
        if self.is_exporting:
            return rx.toast.info("导出仍在进行中", duration=2000)
        if not self.export_file_url or not self.export_file_name:
            return rx.toast.error("没有可下载的导出文件", duration=2200)

        file_path = Path(self.export_file_url)
        exports_root = (Path("uploaded_files") / "exports").resolve()

        try:
            resolved = file_path.resolve()
        except Exception:
            return rx.toast.error("导出文件路径无效", duration=2200)

        if exports_root not in resolved.parents:
            return rx.toast.error("文件访问被拒绝", duration=2200)
        if not resolved.exists() or not resolved.is_file():
            return rx.toast.error("导出文件不存在，请重新导出", duration=2200)

        file_data = resolved.read_bytes()
        return [
            rx.download(
                data=file_data,
                filename=self.export_file_name,
                mime_type="text/csv;charset=utf-8",
            ),
            type(self).cleanup_export_modal_after_download,
        ]

    @rx.event(background=True)
    async def cleanup_export_modal_after_download(self):
        await asyncio.sleep(0.2)
        async with self:
            self.show_export_modal = False

    # ==================== Computed ====================

    @rx.var
    def normalized_users(self) -> List[Dict[str, Any]]:
        return [self._normalize_user(user) for user in self.users]

    @rx.var
    def total_users(self) -> int:
        return len(self.normalized_users)

    @rx.var
    def active_users(self) -> int:
        return sum(1 for user in self.normalized_users if user["status"] == "active")

    @rx.var
    def total_balance(self) -> float:
        return round(
            sum(float(user.get("balance", 0)) for user in self.normalized_users),
            2,
        )

    @rx.var
    def bot_filter_options(self) -> List[str]:
        options = ["全部 Bot"]
        seen = set(options)
        for user in self.normalized_users:
            for source in user.get("bot_sources", []):
                bot_name = str(source.get("bot_name") or "").strip()
                if bot_name and bot_name not in seen:
                    options.append(bot_name)
                    seen.add(bot_name)
        return options

    @rx.var
    def export_bot_options(self) -> List[str]:
        return self.bot_filter_options

    @rx.var
    def filtered_users(self) -> List[Dict[str, Any]]:
        users = self.normalized_users

        if self.search_query:
            query = self.search_query.lower().strip()
            users = [
                user
                for user in users
                if query in str(user.get("name", "")).lower()
                or query in str(user.get("telegram_id", "")).lower()
                or query in str(user.get("username") or "").lower()
            ]

        if self.filter_status == "正常":
            users = [user for user in users if user.get("status") == "active"]
        elif self.filter_status == "封禁":
            users = [user for user in users if user.get("status") == "banned"]

        if self.filter_bot != "全部 Bot":
            users = [
                user
                for user in users
                if self.filter_bot
                in [source["bot_name"] for source in user.get("bot_sources", [])]
            ]

        users = sorted(
            users,
            key=lambda user: str(user.get("created_at", "")),
            reverse=True,
        )
        return users

    @rx.var
    def filtered_total(self) -> int:
        return len(self.filtered_users)

    @rx.var
    def total_pages(self) -> int:
        return max(1, (self.filtered_total + self.page_size - 1) // self.page_size)

    @rx.var
    def paginated_users(self) -> List[Dict[str, Any]]:
        start = (self.current_page - 1) * self.page_size
        end = start + self.page_size
        return self.filtered_users[start:end]

    @rx.var
    def display_range(self) -> str:
        total = self.filtered_total
        if total == 0:
            return "0 - 0"
        start = (self.current_page - 1) * self.page_size + 1
        end = min(self.current_page * self.page_size, total)
        return f"{start} - {end}"

    @rx.var
    def selected_user_name(self) -> str:
        return str(self.selected_user.get("name", "")) if self.selected_user else ""

    @rx.var
    def selected_user_telegram_id(self) -> str:
        return str(self.selected_user.get("telegram_id", "")) if self.selected_user else ""

    @rx.var
    def selected_user_username(self) -> str:
        if not self.selected_user:
            return "-"
        return str(self.selected_user.get("username") or "-")

    @rx.var
    def selected_user_balance(self) -> str:
        if not self.selected_user:
            return "0.00"
        balance = Decimal(str(self.selected_user.get("balance", 0))).quantize(
            Decimal("0.01"), rounding=ROUND_HALF_UP
        )
        return f"{balance:.2f}"

    @rx.var
    def selected_user_total_deposit(self) -> str:
        if not self.selected_user:
            return "0.00"
        total_deposit = Decimal(str(self.selected_user.get("total_deposit", 0))).quantize(
            Decimal("0.01"), rounding=ROUND_HALF_UP
        )
        return f"{total_deposit:.2f}"

    @rx.var
    def selected_user_orders(self) -> str:
        if not self.selected_user:
            return "0"
        return str(self.selected_user.get("orders", 0))

    @rx.var
    def selected_user_current_balance_label(self) -> str:
        return f"${self.selected_user_balance}"

    @rx.var
    def selected_user_bot_sources(self) -> List[Dict[str, Any]]:
        if not self.selected_user:
            return []
        return list(self.selected_user.get("bot_sources", []))

    @rx.var
    def selected_user_bot_source_options(self) -> List[str]:
        return [src["bot_name"] for src in self.selected_user_bot_sources]

    @rx.var
    def selected_user_source_bots_label(self) -> str:
        if not self.selected_user_bot_sources:
            return "-"
        return " / ".join([src["bot_name"] for src in self.selected_user_bot_sources])

    @rx.var
    def selected_user_deposit_records(self) -> List[Dict[str, Any]]:
        if not self.selected_user:
            return []
        records = list(self.selected_user.get("deposit_records", []))
        return sorted(records, key=lambda item: str(item.get("created_at", "")), reverse=True)

    @rx.var
    def selected_user_purchase_records(self) -> List[Dict[str, Any]]:
        if not self.selected_user:
            return []
        records = list(self.selected_user.get("purchase_records", []))
        return sorted(records, key=lambda item: str(item.get("created_at", "")), reverse=True)

    @rx.var
    def balance_confirm_summary(self) -> str:
        if not self.pending_balance_payload:
            return ""
        payload = self.pending_balance_payload
        return (
            f"{payload.get('action', '')} ${payload.get('amount', '0.00')}，"
            f"来源 Bot: {payload.get('source_bot', '-')}"
        )

    @rx.var
    def export_can_download(self) -> bool:
        return self.export_status == "completed" and bool(self.export_file_name)

    @rx.var
    def export_is_failed(self) -> bool:
        return self.export_status == "failed"

    @rx.var
    def export_record_progress_text(self) -> str:
        if self.export_total_records <= 0:
            return ""
        return f"{self.export_processed_records}/{self.export_total_records}"

    @rx.var
    def has_selected_user_deposit_records(self) -> bool:
        return len(self.selected_user_deposit_records) > 0

    @rx.var
    def has_selected_user_purchase_records(self) -> bool:
        return len(self.selected_user_purchase_records) > 0
