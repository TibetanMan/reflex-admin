"""Bot 管理状态"""

import reflex as rx
from typing import List, Dict, Any, Optional
from pydantic import BaseModel


class BotInfo(BaseModel):
    """Bot 信息数据模型"""
    id: int
    name: str
    username: str
    token_masked: str
    status: str  # "active" or "inactive"
    owner: str
    usdt_address: str = ""
    users: int = 0
    orders: int = 0
    revenue: float = 0.0
    created_at: str = ""


class BotState(rx.State):
    """Bot 管理状态"""
    
    # Bot 列表 - 使用类型化的模型
    bots: List[BotInfo] = [
        BotInfo(
            id=1,
            name="主站 Bot",
            username="@main_shop_bot",
            token_masked="6123456789:AAAA...XXXX",
            status="active",
            owner="平台自营",
            usdt_address="TXyz123abc456def789",
            users=1234,
            orders=156,
            revenue=2450.00,
            created_at="2024-01-15",
        ),
        BotInfo(
            id=2,
            name="代理A Bot",
            username="@agent_a_bot",
            token_masked="6234567890:BBBB...YYYY",
            status="active",
            owner="代理商A",
            usdt_address="TXyz789def012ghi345",
            users=456,
            orders=42,
            revenue=680.50,
            created_at="2024-01-20",
        ),
        BotInfo(
            id=3,
            name="代理B Bot",
            username="@agent_b_bot",
            token_masked="6345678901:CCCC...ZZZZ",
            status="inactive",
            owner="代理商B",
            usdt_address="",
            users=289,
            orders=28,
            revenue=420.00,
            created_at="2024-02-01",
        ),
    ]
    
    # 单独跟踪每个 Bot 的状态 (用于动态UI更新)
    # 注意：现在状态存储在 BotInfo.status 中
    bot1_active: bool = True
    bot2_active: bool = True
    bot3_active: bool = False
    
    # 可选的归属列表
    owner_options: List[str] = ["平台自营", "代理商A", "代理商B", "代理商C"]
    
    # 弹窗控制
    show_create_modal: bool = False
    show_edit_modal: bool = False
    show_delete_modal: bool = False
    
    # 表单数据
    form_name: str = ""
    form_token: str = ""
    form_owner: str = "平台自营"
    form_usdt_address: str = ""
    form_welcome_message: str = ""
    selected_bot_id: Optional[int] = None
    selected_bot_name: str = ""
    
    # 筛选 - 添加默认值
    search_query: str = ""
    filter_status: str = "全部状态"
    filter_owner: str = "全部归属"
    
    def open_create_modal(self):
        self.show_create_modal = True
        self.form_name = ""
        self.form_token = ""
        self.form_owner = "平台自营"
        self.form_usdt_address = ""
        self.form_welcome_message = ""
    
    def close_create_modal(self):
        self.show_create_modal = False
        self.form_name = ""
        self.form_token = ""
        self.form_owner = "平台自营"
        self.form_usdt_address = ""
        self.form_welcome_message = ""
    
    def open_edit_modal(self, bot_id: int):
        self.selected_bot_id = bot_id
        # 加载 bot 数据到表单
        for bot in self.bots:
            if bot.id == bot_id:
                self.form_name = bot.name
                self.form_owner = bot.owner
                self.form_usdt_address = bot.usdt_address
                self.selected_bot_name = bot.name
                break
        self.show_edit_modal = True
    
    def close_edit_modal(self):
        self.show_edit_modal = False
        self.selected_bot_id = None
        self.form_name = ""
        self.form_owner = "平台自营"
        self.form_usdt_address = ""
    
    def open_delete_modal(self, bot_id: int):
        self.selected_bot_id = bot_id
        for bot in self.bots:
            if bot.id == bot_id:
                self.selected_bot_name = bot.name
                break
        self.show_delete_modal = True
    
    def close_delete_modal(self):
        self.show_delete_modal = False
        self.selected_bot_id = None
        self.selected_bot_name = ""
    
    def set_form_name(self, value: str):
        self.form_name = value
    
    def set_form_token(self, value: str):
        self.form_token = value
    
    def set_form_owner(self, value: str):
        self.form_owner = value
    
    def set_form_usdt_address(self, value: str):
        self.form_usdt_address = value
    
    def set_form_welcome_message(self, value: str):
        self.form_welcome_message = value
    
    def set_search_query(self, value: str):
        self.search_query = value
    
    def set_filter_status(self, value: str):
        self.filter_status = value
    
    def set_filter_owner(self, value: str):
        self.filter_owner = value
    
    def create_bot(self):
        """创建新 Bot"""
        if not self.form_name or not self.form_token:
            return rx.toast.error("请填写必填项", duration=3000)
        
        # 模拟创建逻辑
        new_id = max(b.id for b in self.bots) + 1 if self.bots else 1
        new_bot = BotInfo(
            id=new_id,
            name=self.form_name,
            username=f"@new_bot_{new_id}",
            token_masked=self.form_token[:10] + "...XXXX" if len(self.form_token) > 10 else self.form_token + "...XXXX",
            status="inactive",
            owner=self.form_owner,
            usdt_address=self.form_usdt_address,
            users=0,
            orders=0,
            revenue=0.00,
            created_at="2026-02-08",
        )
        self.bots = self.bots + [new_bot]
        self.close_create_modal()
        return rx.toast.success(f"Bot「{self.form_name}」创建成功", duration=3000)
    
    def update_bot(self):
        """更新 Bot"""
        if not self.form_name:
            return rx.toast.error("请填写 Bot 名称", duration=3000)
        
        # 更新逻辑 - 使用 BotInfo 类型
        updated_bots = []
        for bot in self.bots:
            if bot.id == self.selected_bot_id:
                # 创建新的 BotInfo 对象（因为 rx.Base 是不可变的）
                updated_bot = BotInfo(
                    id=bot.id,
                    name=self.form_name,
                    username=bot.username,
                    token_masked=bot.token_masked,
                    status=bot.status,
                    owner=self.form_owner,
                    usdt_address=self.form_usdt_address,
                    users=bot.users,
                    orders=bot.orders,
                    revenue=bot.revenue,
                    created_at=bot.created_at,
                )
                updated_bots.append(updated_bot)
            else:
                updated_bots.append(bot)
        self.bots = updated_bots
        bot_name = self.form_name
        self.close_edit_modal()
        return rx.toast.success(f"Bot「{bot_name}」更新成功", duration=3000)
    
    def delete_bot(self):
        """删除 Bot"""
        bot_name = self.selected_bot_name
        self.bots = [b for b in self.bots if b.id != self.selected_bot_id]
        self.close_delete_modal()
        return rx.toast.success(f"Bot「{bot_name}」已删除", duration=3000)
    
    def toggle_bot_status(self, bot_id: int):
        """切换指定 Bot 的状态"""
        updated_bots = []
        bot_name = ""
        new_status = ""
        for bot in self.bots:
            if bot.id == bot_id:
                bot_name = bot.name
                new_status = "inactive" if bot.status == "active" else "active"
                updated_bot = BotInfo(
                    id=bot.id,
                    name=bot.name,
                    username=bot.username,
                    token_masked=bot.token_masked,
                    status=new_status,
                    owner=bot.owner,
                    usdt_address=bot.usdt_address,
                    users=bot.users,
                    orders=bot.orders,
                    revenue=bot.revenue,
                    created_at=bot.created_at,
                )
                updated_bots.append(updated_bot)
            else:
                updated_bots.append(bot)
        self.bots = updated_bots
        status_text = "启动" if new_status == "active" else "停止"
        return rx.toast.success(f"{bot_name} 已{status_text}", duration=2000)
    
    # 保留旧方法以保持向后兼容
    def toggle_bot1_status(self):
        """切换 Bot1 状态"""
        return self.toggle_bot_status(1)
    
    def toggle_bot2_status(self):
        """切换 Bot2 状态"""
        return self.toggle_bot_status(2)
    
    def toggle_bot3_status(self):
        """切换 Bot3 状态"""
        return self.toggle_bot_status(3)
    
    @rx.var
    def total_bots(self) -> int:
        return len(self.bots)
    
    @rx.var
    def active_bots(self) -> int:
        # 使用 bots 列表的 status 字段计算
        return sum(1 for b in self.bots if b.status == "active")
    
    @rx.var
    def total_bot_users(self) -> int:
        return sum(b.users for b in self.bots)
    
    @rx.var
    def total_bot_revenue(self) -> float:
        return sum(b.revenue for b in self.bots)
