"""认证状态管理 - 支持多角色"""

import reflex as rx
from enum import Enum
from typing import Optional
from datetime import datetime

from shared.models.admin_user import AdminRole


# 测试用户数据 (后续替换为数据库)
TEST_USERS = {
    "admin": {
        "password": "admin123",
        "name": "超级管理员",
        "role": AdminRole.SUPER_ADMIN,
        "avatar": "/avatar/admin.png",
    },
    "agent1": {
        "password": "agent123",
        "name": "代理商A",
        "role": AdminRole.AGENT,
        "avatar": "/avatar/agent.png",
    },
    "merchant1": {
        "password": "merchant123",
        "name": "供货商A",
        "role": AdminRole.MERCHANT,
        "avatar": "/avatar/merchant.png",
    },
}


class AuthState(rx.State):
    """认证状态"""
    
    # 用户信息
    is_logged_in: bool = False
    username: str = ""
    user_name: str = ""
    user_role: str = ""
    user_avatar: str = ""
    
    # 登录表单
    login_username: str = ""
    login_password: str = ""
    remember_me: bool = False
    is_loading: bool = False
    error_message: str = ""
    
    def set_login_username(self, value: str):
        self.login_username = value
        self.error_message = ""
    
    def set_login_password(self, value: str):
        self.login_password = value
        self.error_message = ""
    
    def set_remember_me(self, value: bool):
        self.remember_me = value
    
    def handle_login(self):
        """处理登录"""
        self.is_loading = True
        
        if not self.login_username or not self.login_password:
            self.error_message = "请输入用户名和密码"
            self.is_loading = False
            return
        
        # 验证用户
        user = TEST_USERS.get(self.login_username)
        if user and user["password"] == self.login_password:
            self.is_logged_in = True
            self.username = self.login_username
            self.user_name = user["name"]
            self.user_role = user["role"].value
            self.user_avatar = user.get("avatar", "")
            self.error_message = ""
            self.is_loading = False
            # 清空表单
            self.login_username = ""
            self.login_password = ""
            return rx.redirect("/")
        else:
            self.error_message = "用户名或密码错误"
            self.is_loading = False
    
    def handle_logout(self):
        """处理登出"""
        self.is_logged_in = False
        self.username = ""
        self.user_name = ""
        self.user_role = ""
        self.user_avatar = ""
        return rx.redirect("/login")
    
    def check_auth(self):
        """检查认证状态，未登录则跳转"""
        if not self.is_logged_in:
            return rx.redirect("/login")
    
    @rx.var
    def is_super_admin(self) -> bool:
        """是否是超级管理员"""
        return self.user_role == AdminRole.SUPER_ADMIN.value
    
    @rx.var
    def is_agent(self) -> bool:
        """是否是代理商"""
        return self.user_role == AdminRole.AGENT.value
    
    @rx.var
    def is_merchant(self) -> bool:
        """是否是供货商"""
        return self.user_role == AdminRole.MERCHANT.value
    
    @rx.var
    def role_display(self) -> str:
        """角色显示名称"""
        role_names = {
            AdminRole.SUPER_ADMIN.value: "超级管理员",
            AdminRole.AGENT.value: "代理商",
            AdminRole.MERCHANT.value: "供货商",
        }
        return role_names.get(self.user_role, "未知角色")
    
    @rx.var
    def can_manage_bots(self) -> bool:
        """是否可以管理 Bot"""
        return self.user_role in [AdminRole.SUPER_ADMIN.value, AdminRole.AGENT.value]
    
    @rx.var
    def can_manage_inventory(self) -> bool:
        """是否可以管理库存"""
        return self.user_role in [AdminRole.SUPER_ADMIN.value, AdminRole.MERCHANT.value]
    
    @rx.var
    def can_manage_agents(self) -> bool:
        """是否可以管理代理"""
        return self.user_role == AdminRole.SUPER_ADMIN.value
    
    @rx.var
    def can_view_all_data(self) -> bool:
        """是否可以查看所有数据"""
        return self.user_role == AdminRole.SUPER_ADMIN.value
