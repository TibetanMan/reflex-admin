"""库存管理状态"""

import reflex as rx
from typing import List, Dict, Any, Optional
from datetime import datetime
from pydantic import BaseModel
import os


# 数据存储目录
DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "data")


class InventoryItem(BaseModel):
    """库存项数据模型"""
    id: int
    name: str  # 库名称
    category: str  # 分类
    merchant: str  # 商家
    unit_price: float  # 单价
    pick_price: float  # 挑头价格
    status: str  # 状态: active, inactive
    sold: int  # 已售
    remaining: int  # 剩余库存
    total: int  # 总库存
    created_at: str  # 创建时间
    

class InventoryState(rx.State):
    """库存管理状态"""
    
    # 筛选条件
    search_query: str = ""  # 搜索 商家 和 id
    filter_merchant: str = ""  # 筛选商家
    filter_status: str = ""  # 筛选状态
    
    # 排序
    sort_order: str = "desc"  # 创建时间排序: asc, desc
    
    # 分页 - 安全处理
    current_page: int = 1
    page_size: int = 20  # 20-50
    total_items: int = 0
    page_size_options: List[int] = [20, 30, 40, 50]
    
    # 库存列表
    inventory_items: List[InventoryItem] = [
        # 模拟数据
        InventoryItem(
            id=1,
            name="US-VISA-Premium",
            category="全资库-一手",
            merchant="平台自营",
            unit_price=5.50,
            pick_price=1.20,
            status="active",
            sold=450,
            remaining=750,
            total=1200,
            created_at="2024-02-01 10:30:00",
        ),
        InventoryItem(
            id=2,
            name="US-MC-Standard",
            category="全资库-二手",
            merchant="代理商A",
            unit_price=3.80,
            pick_price=0.80,
            status="active",
            sold=320,
            remaining=680,
            total=1000,
            created_at="2024-02-03 14:20:00",
        ),
        InventoryItem(
            id=3,
            name="UK-VISA-Basic",
            category="裸资库",
            merchant="代理商B",
            unit_price=2.50,
            pick_price=0.50,
            status="inactive",
            sold=180,
            remaining=320,
            total=500,
            created_at="2024-02-05 09:15:00",
        ),
        InventoryItem(
            id=4,
            name="CA-VISA-Sale",
            category="特价库",
            merchant="供应商C",
            unit_price=1.80,
            pick_price=0.30,
            status="active",
            sold=600,
            remaining=200,
            total=800,
            created_at="2024-02-06 16:45:00",
        ),
        InventoryItem(
            id=5,
            name="AU-VISA-Premium",
            category="全资库-一手",
            merchant="平台自营",
            unit_price=6.00,
            pick_price=1.50,
            status="active",
            sold=280,
            remaining=420,
            total=700,
            created_at="2024-02-07 11:00:00",
        ),
    ]
    
    # 商家列表 (模拟数据)
    merchant_names: List[str] = [
        "平台自营",
        "代理商A",
        "代理商B",
        "供应商C",
    ]
    
    # 库存分类选项
    inventory_categories: List[str] = [
        "全资库-一手",
        "全资库-二手",
        "裸资库",
        "特价库",
    ]
    
    # 状态选项
    status_options: List[str] = ["全部", "可售", "停售"]
    
    # 商家筛选选项 (带"全部")
    merchant_filter_options: List[str] = [
        "全部",
        "平台自营",
        "代理商A",
        "代理商B",
        "供应商C",
    ]
    
    # 导入相关
    is_importing: bool = False
    import_progress: int = 0
    import_result: Dict[str, int] = {}
    upload_file_content: str = ""
    delimiter: str = "|"
    preview_data: List[Dict[str, Any]] = []
    
    # 导入表单字段
    import_name: str = ""  # 库名称
    import_merchant: str = ""  # 商家绑定
    import_category: str = "全资库-一手"  # 分类
    import_unit_price: float = 0.0  # 单价
    import_pick_price: float = 0.0  # 挑头价格
    import_push_ad: bool = False  # 是否推送广告
    import_ad_content: str = ""  # 广告内容
    
    # 弹窗控制
    show_import_modal: bool = False
    show_delete_modal: bool = False
    show_price_modal: bool = False
    selected_item_id: Optional[int] = None
    
    # 价格编辑
    edit_unit_price: float = 0.0
    edit_pick_price: float = 0.0
    
    # ==================== 筛选和搜索 ====================
    
    def set_search_query(self, value: str):
        self.search_query = value
        self.current_page = 1  # 搜索时重置到第一页
    
    def set_filter_merchant(self, value: str):
        self.filter_merchant = value if value != "全部" else ""
        self.current_page = 1
    
    def set_filter_status(self, value: str):
        if value == "可售":
            self.filter_status = "active"
        elif value == "停售":
            self.filter_status = "inactive"
        else:
            self.filter_status = ""
        self.current_page = 1
    
    def set_sort_order(self, value: str):
        if value == "最新优先":
            self.sort_order = "desc"
        else:
            self.sort_order = "asc"
        self.current_page = 1
    
    # ==================== 分页处理 ====================
    
    def set_page_size(self, value: str):
        """设置每页显示数量"""
        try:
            size = int(value)
            # 安全边界检查
            if size < 20:
                size = 20
            elif size > 50:
                size = 50
            self.page_size = size
            self.current_page = 1  # 重置到第一页
        except ValueError:
            self.page_size = 20
    
    def go_to_page(self, page: int):
        """安全的分页跳转"""
        total_pages = self.total_pages
        if page < 1:
            page = 1
        elif page > total_pages:
            page = total_pages
        self.current_page = max(1, page)
    
    def next_page(self):
        """下一页"""
        if self.current_page < self.total_pages:
            self.current_page += 1
    
    def prev_page(self):
        """上一页"""
        if self.current_page > 1:
            self.current_page -= 1
    
    def first_page(self):
        """第一页"""
        self.current_page = 1
    
    def last_page(self):
        """最后一页"""
        self.current_page = self.total_pages
    
    @rx.var
    def total_pages(self) -> int:
        """总页数"""
        total = len(self.filtered_items)
        return max(1, (total + self.page_size - 1) // self.page_size)
    
    @rx.var
    def filtered_items(self) -> List[InventoryItem]:
        """筛选后的列表"""
        items = self.inventory_items
        
        # 搜索过滤 (商家和ID)
        if self.search_query:
            query = self.search_query.lower()
            items = [
                item for item in items
                if query in item.merchant.lower() or query in str(item.id)
            ]
        
        # 商家筛选
        if self.filter_merchant:
            items = [item for item in items if item.merchant == self.filter_merchant]
        
        # 状态筛选
        if self.filter_status:
            items = [item for item in items if item.status == self.filter_status]
        
        # 按创建时间排序
        items = sorted(
            items,
            key=lambda x: x.created_at,
            reverse=(self.sort_order == "desc")
        )
        
        return items
    
    @rx.var
    def paginated_items(self) -> List[InventoryItem]:
        """分页后的列表"""
        start = (self.current_page - 1) * self.page_size
        end = start + self.page_size
        return self.filtered_items[start:end]
    
    @rx.var
    def display_total(self) -> int:
        """显示的总数"""
        return len(self.filtered_items)
    
    @rx.var
    def display_range(self) -> str:
        """当前显示范围"""
        total = len(self.filtered_items)
        if total == 0:
            return "0 - 0"
        start = (self.current_page - 1) * self.page_size + 1
        end = min(self.current_page * self.page_size, total)
        return f"{start} - {end}"
    
    # ==================== 导入表单 ====================
    
    def set_delimiter(self, value: str):
        if "竖线" in value or "|" in value:
            self.delimiter = "|"
        elif "冒号" in value or ":" in value:
            self.delimiter = ":"
        elif "逗号" in value or "," in value:
            self.delimiter = ","
        else:
            self.delimiter = "|"
    
    def set_import_name(self, value: str):
        self.import_name = value
    
    def set_import_merchant(self, value: str):
        self.import_merchant = value
    
    def set_import_category(self, value: str):
        self.import_category = value
    
    def set_import_unit_price(self, value: str):
        try:
            self.import_unit_price = float(value) if value else 0.0
        except ValueError:
            self.import_unit_price = 0.0
    
    def set_import_pick_price(self, value: str):
        try:
            self.import_pick_price = float(value) if value else 0.0
        except ValueError:
            self.import_pick_price = 0.0
    
    def set_import_push_ad(self, value: bool):
        self.import_push_ad = value
    
    def set_import_ad_content(self, value: str):
        self.import_ad_content = value
    
    def open_import_modal(self):
        """打开导入弹窗"""
        self.show_import_modal = True
        self.upload_file_content = ""
        self.preview_data = []
        self.import_result = {}
        self.is_importing = False
        self.import_progress = 0
        # 重置表单字段
        self.import_name = ""
        self.import_merchant = ""
        self.import_category = "全资库-一手"
        self.import_unit_price = 0.0
        self.import_pick_price = 0.0
        self.import_push_ad = False
        self.import_ad_content = ""
    
    def close_import_modal(self):
        """关闭导入弹窗"""
        self.show_import_modal = False
        self.upload_file_content = ""
        self.preview_data = []
        self.import_result = {}
        self.is_importing = False
        self.import_progress = 0
    
    async def handle_file_upload(self, files: List[rx.UploadFile]):
        """处理文件上传"""
        if not files:
            return
        
        file = files[0]
        content = await file.read()
        self.upload_file_content = content.decode("utf-8")
        
        # 生成预览
        lines = self.upload_file_content.strip().split("\n")[:5]
        self.preview_data = []
        for i, line in enumerate(lines):
            parts = line.split(self.delimiter)
            self.preview_data.append({
                "index": i + 1,
                "raw": line[:50] + "..." if len(line) > 50 else line,
                "fields": len(parts),
                "bin": parts[0][:6] if parts else "",
            })
    
    def start_import(self):
        """开始导入 - 保存到本地 txt 文件"""
        if not self.upload_file_content:
            return rx.toast.error("请先上传文件", duration=3000)
        
        if not self.import_name:
            return rx.toast.error("请输入库名称", duration=3000)
        
        if not self.import_merchant:
            return rx.toast.error("请选择商家", duration=3000)
        
        self.is_importing = True
        self.import_progress = 0
        
        try:
            # 确保数据目录存在
            os.makedirs(DATA_DIR, exist_ok=True)
            
            # 解析数据
            lines = self.upload_file_content.strip().split("\n")
            total = len(lines)
            success = 0
            duplicate = 0
            invalid = 0
            
            # 生成文件名
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"inventory_{self.import_name}_{timestamp}.txt"
            filepath = os.path.join(DATA_DIR, filename)
            
            # 存储有效数据
            valid_lines = []
            seen_records = set()
            
            for i, line in enumerate(lines):
                line = line.strip()
                if not line:
                    continue
                
                parts = line.split(self.delimiter)
                
                if len(parts) < 1 or not parts[0]:
                    invalid += 1
                    continue
                
                record_key = parts[0]
                if record_key in seen_records:
                    duplicate += 1
                    continue
                
                seen_records.add(record_key)
                valid_lines.append(line)
                success += 1
                
                self.import_progress = int((i + 1) / total * 100)
            
            # 保存到文件
            with open(filepath, "w", encoding="utf-8") as f:
                f.write(f"# 导入时间: {datetime.now().isoformat()}\n")
                f.write(f"# 库名称: {self.import_name}\n")
                f.write(f"# 商家: {self.import_merchant}\n")
                f.write(f"# 分类: {self.import_category}\n")
                f.write(f"# 单价: ${self.import_unit_price}\n")
                f.write(f"# 挑头价格: ${self.import_pick_price}\n")
                f.write(f"# 分隔符: {self.delimiter}\n")
                f.write(f"# 推送广告: {'是' if self.import_push_ad else '否'}\n")
                if self.import_push_ad and self.import_ad_content:
                    f.write(f"# 广告内容: {self.import_ad_content[:100]}...\n")
                f.write(f"# 总计: {total}, 成功: {success}, 重复: {duplicate}, 无效: {invalid}\n")
                f.write("#" + "=" * 60 + "\n")
                for line in valid_lines:
                    f.write(line + "\n")
            
            # 添加到库存列表
            new_id = max([item.id for item in self.inventory_items], default=0) + 1
            new_item = InventoryItem(
                id=new_id,
                name=self.import_name,
                category=self.import_category,
                merchant=self.import_merchant,
                unit_price=self.import_unit_price,
                pick_price=self.import_pick_price,
                status="active",
                sold=0,
                remaining=success,
                total=success,
                created_at=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            )
            self.inventory_items = self.inventory_items + [new_item]
            
            self.import_result = {
                "total": total,
                "success": success,
                "duplicate": duplicate,
                "invalid": invalid,
            }
            
            self.import_progress = 100
            self.is_importing = False
            self.show_import_modal = False
            
            return rx.toast.success(
                f"导入完成！成功 {success} 条，已创建库「{self.import_name}」",
                duration=5000
            )
            
        except Exception as e:
            self.is_importing = False
            self.import_progress = 0
            return rx.toast.error(f"导入失败: {str(e)}", duration=5000)
    
    # ==================== 删除弹窗 ====================
    
    def open_delete_modal(self, item_id: int):
        self.selected_item_id = item_id
        self.show_delete_modal = True
    
    def close_delete_modal(self):
        self.show_delete_modal = False
        self.selected_item_id = None
    
    def delete_item(self):
        """删除选中项"""
        if self.selected_item_id:
            self.inventory_items = [
                item for item in self.inventory_items
                if item.id != self.selected_item_id
            ]
        self.close_delete_modal()
        return rx.toast.success("已删除", duration=2000)
    
    # ==================== 价格编辑弹窗 ====================
    
    def open_price_modal(self, item_id: int):
        """打开价格编辑弹窗"""
        self.selected_item_id = item_id
        # 获取当前价格
        for item in self.inventory_items:
            if item.id == item_id:
                self.edit_unit_price = item.unit_price
                self.edit_pick_price = item.pick_price
                break
        self.show_price_modal = True
    
    def close_price_modal(self):
        self.show_price_modal = False
        self.selected_item_id = None

    def handle_price_modal_change(self, is_open: bool):
        if not is_open:
            self.close_price_modal()
    
    def set_edit_unit_price(self, value: str):
        try:
            self.edit_unit_price = float(value) if value else 0.0
        except ValueError:
            pass
    
    def set_edit_pick_price(self, value: str):
        try:
            self.edit_pick_price = float(value) if value else 0.0
        except ValueError:
            pass
    
    def update_price(self):
        """更新价格"""
        if self.selected_item_id:
            new_items = []
            for item in self.inventory_items:
                if item.id == self.selected_item_id:
                    new_items.append(InventoryItem(
                        id=item.id,
                        name=item.name,
                        category=item.category,
                        merchant=item.merchant,
                        unit_price=self.edit_unit_price,
                        pick_price=self.edit_pick_price,
                        status=item.status,
                        sold=item.sold,
                        remaining=item.remaining,
                        total=item.total,
                        created_at=item.created_at,
                    ))
                else:
                    new_items.append(item)
            self.inventory_items = new_items
        self.close_price_modal()
        return rx.toast.success("价格已更新", duration=2000)
    
    # ==================== 状态切换 ====================
    
    def toggle_status(self, item_id: int):
        """切换可售状态"""
        new_items = []
        for item in self.inventory_items:
            if item.id == item_id:
                new_status = "inactive" if item.status == "active" else "active"
                new_items.append(InventoryItem(
                    id=item.id,
                    name=item.name,
                    category=item.category,
                    merchant=item.merchant,
                    unit_price=item.unit_price,
                    pick_price=item.pick_price,
                    status=new_status,
                    sold=item.sold,
                    remaining=item.remaining,
                    total=item.total,
                    created_at=item.created_at,
                ))
            else:
                new_items.append(item)
        self.inventory_items = new_items
        return rx.toast.info("状态已更新", duration=2000)
    
    # ==================== 刷新 ====================
    
    def refresh_list(self):
        """刷新列表"""
        return rx.toast.info("列表已刷新", duration=2000)
    
    @rx.var
    def has_preview(self) -> bool:
        return len(self.preview_data) > 0
    
    @rx.var
    def has_import_result(self) -> bool:
        return len(self.import_result) > 0
    
    @rx.var
    def selected_item_name(self) -> str:
        """获取选中项的名称"""
        if self.selected_item_id:
            for item in self.inventory_items:
                if item.id == self.selected_item_id:
                    return item.name
        return ""
