"""仪表盘状态管理"""

import reflex as rx
from typing import List, Dict, Any
from datetime import datetime, timedelta


class DashboardState(rx.State):
    """仪表盘状态"""
    
    # 统计数据
    today_sales: float = 1234.56
    today_orders: int = 42
    new_users: int = 15
    total_stock: int = 5678
    
    # 趋势数据 (与昨日对比)
    sales_trend: float = 12.5   # 正数表示增长
    orders_trend: float = 8.3
    users_trend: float = -5.2   # 负数表示下降
    stock_trend: float = 3.1
    
    # 图表数据
    sales_chart_data: List[Dict[str, Any]] = [
        {"date": "周一", "销售额": 1200, "订单数": 35},
        {"date": "周二", "销售额": 1800, "订单数": 48},
        {"date": "周三", "销售额": 1500, "订单数": 42},
        {"date": "周四", "销售额": 2100, "订单数": 55},
        {"date": "周五", "销售额": 1900, "订单数": 51},
        {"date": "周六", "销售额": 2500, "订单数": 68},
        {"date": "周日", "销售额": 2200, "订单数": 60},
    ]
    
    # 热门分类
    top_categories: List[Dict[str, Any]] = [
        {"name": "US - VISA", "sales": 450, "stock": 1200, "progress": 65},
        {"name": "UK - MASTERCARD", "sales": 380, "stock": 980, "progress": 72},
        {"name": "CA - VISA", "sales": 320, "stock": 850, "progress": 58},
        {"name": "AU - AMEX", "sales": 280, "stock": 720, "progress": 45},
        {"name": "DE - VISA", "sales": 220, "stock": 600, "progress": 38},
    ]
    
    # 最近订单
    recent_orders: List[Dict[str, Any]] = [
        {
            "id": "ORD20240208001",
            "user": "User_123456",
            "amount": 25.00,
            "items": 5,
            "status": "completed",
            "time": "10分钟前",
        },
        {
            "id": "ORD20240208002",
            "user": "User_789012",
            "amount": 15.50,
            "items": 3,
            "status": "completed",
            "time": "25分钟前",
        },
        {
            "id": "ORD20240208003",
            "user": "User_345678",
            "amount": 42.00,
            "items": 8,
            "status": "pending",
            "time": "1小时前",
        },
        {
            "id": "ORD20240208004",
            "user": "User_901234",
            "amount": 8.00,
            "items": 2,
            "status": "refunded",
            "time": "2小时前",
        },
    ]
    
    # 最近充值
    recent_deposits: List[Dict[str, Any]] = [
        {
            "user": "User_123456",
            "amount": 100.00,
            "status": "completed",
            "time": "5分钟前",
        },
        {
            "user": "User_567890",
            "amount": 50.00,
            "status": "confirming",
            "time": "15分钟前",
        },
        {
            "user": "User_234567",
            "amount": 200.00,
            "status": "completed",
            "time": "30分钟前",
        },
    ]
    
    # Bot 状态
    bot_stats: List[Dict[str, Any]] = [
        {"name": "主站 Bot", "users": 1234, "orders": 156, "status": "active"},
        {"name": "代理A Bot", "users": 456, "orders": 42, "status": "active"},
        {"name": "代理B Bot", "users": 289, "orders": 28, "status": "inactive"},
    ]
    
    def refresh_data(self):
        """刷新数据"""
        # TODO: 从数据库获取真实数据
        pass
    
    @rx.var
    def formatted_sales(self) -> str:
        """格式化销售额"""
        return f"${self.today_sales:,.2f}"
    
    @rx.var
    def sales_trend_color(self) -> str:
        """销售趋势颜色"""
        return "green" if self.sales_trend >= 0 else "red"
    
    @rx.var
    def orders_trend_color(self) -> str:
        """订单趋势颜色"""
        return "green" if self.orders_trend >= 0 else "red"
    
    @rx.var
    def users_trend_color(self) -> str:
        """用户趋势颜色"""
        return "green" if self.users_trend >= 0 else "red"
    
    @rx.var
    def stock_trend_color(self) -> str:
        """库存趋势颜色"""
        return "green" if self.stock_trend >= 0 else "red"
