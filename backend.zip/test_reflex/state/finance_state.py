"""Finance page state."""

from __future__ import annotations

from datetime import datetime
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from typing import Any, Dict, List

import reflex as rx


STATUS_LABEL_TO_CODE = {
    "全部状态": "",
    "已完成": "completed",
    "确认中": "confirming",
}


class FinanceState(rx.State):
    """Finance state for deposits and wallet cards."""

    deposits: List[Dict[str, Any]] = [
        {
            "id": 1,
            "deposit_no": "DEP20240208001",
            "user": "Alice (@user_alice)",
            "user_id": 1,
            "bot": "主站 Bot",
            "amount": 100.00,
            "actual_amount": 100.00,
            "method": "USDT TRC20",
            "to_address": "TXyz...abc",
            "tx_hash": "0x1234...5678",
            "status": "completed",
            "created_at": "2024-02-08 10:00",
            "completed_at": "2024-02-08 10:05",
        },
        {
            "id": 2,
            "deposit_no": "DEP20240208002",
            "user": "Bob (@user_bob)",
            "user_id": 2,
            "bot": "代理A Bot",
            "amount": 50.00,
            "actual_amount": 50.00,
            "method": "USDT TRC20",
            "to_address": "TXyz...def",
            "tx_hash": None,
            "status": "confirming",
            "created_at": "2024-02-08 09:45",
            "completed_at": None,
        },
        {
            "id": 3,
            "deposit_no": "DEP20240207001",
            "user": "User_456789012",
            "user_id": 4,
            "bot": "代理B Bot",
            "amount": 200.00,
            "actual_amount": 200.00,
            "method": "USDT TRC20",
            "to_address": "TXyz...ghi",
            "tx_hash": "0xabcd...efgh",
            "status": "completed",
            "created_at": "2024-02-07 14:30",
            "completed_at": "2024-02-07 14:35",
        },
        {
            "id": 4,
            "deposit_no": "DEP20240207002",
            "user": "Alice (@user_alice)",
            "user_id": 1,
            "bot": "主站 Bot",
            "amount": 50.00,
            "actual_amount": 50.00,
            "method": "手动充值",
            "to_address": "-",
            "tx_hash": None,
            "status": "completed",
            "created_at": "2024-02-07 11:00",
            "completed_at": "2024-02-07 11:00",
        },
    ]

    wallets: List[Dict[str, Any]] = [
        {
            "id": 1,
            "address": "TXyz123...abc456",
            "label": "主收款地址",
            "bot": "主站 Bot",
            "balance": 1250.50,
            "total_received": 5680.00,
            "status": "active",
        },
        {
            "id": 2,
            "address": "TXyz789...def012",
            "label": "代理A收款",
            "bot": "代理A Bot",
            "balance": 320.00,
            "total_received": 1200.00,
            "status": "active",
        },
    ]

    search_query: str = ""
    filter_status: str = "全部状态"
    filter_method: str = ""

    show_manual_deposit_modal: bool = False
    manual_user_id: str = ""
    manual_amount: str = ""
    manual_remark: str = ""

    def _parse_amount(self, value: str) -> Decimal | None:
        try:
            amount = Decimal(value)
        except (InvalidOperation, ValueError):
            return None
        amount = amount.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
        if amount <= 0:
            return None
        return amount

    def set_search_query(self, value: str):
        self.search_query = value

    def set_filter_status(self, value: str):
        self.filter_status = value

    def set_filter_method(self, value: str):
        self.filter_method = value

    def refresh_list(self):
        return rx.toast.info("财务记录已刷新", duration=1500)

    def open_manual_deposit_modal(self):
        self.show_manual_deposit_modal = True
        self.manual_user_id = ""
        self.manual_amount = ""
        self.manual_remark = ""

    def close_manual_deposit_modal(self):
        self.show_manual_deposit_modal = False

    def handle_manual_deposit_modal_change(self, is_open: bool):
        if not is_open:
            self.close_manual_deposit_modal()

    def set_manual_user_id(self, value: str):
        self.manual_user_id = value

    def set_manual_amount(self, value: str):
        self.manual_amount = value

    def set_manual_remark(self, value: str):
        self.manual_remark = value

    def copy_wallet_address(self, address: str):
        value = str(address).strip()
        if not value:
            return rx.toast.error("地址为空，无法复制", duration=1500)
        return [
            rx.set_clipboard(value),
            rx.toast.success("地址已复制", duration=1500),
        ]

    def process_manual_deposit(self):
        """Validate and create one manual deposit record."""
        user_text = self.manual_user_id.strip()
        amount_text = self.manual_amount.strip()
        remark = self.manual_remark.strip() or "手动充值"
        amount = self._parse_amount(amount_text)

        if not user_text:
            return rx.toast.error("请输入用户 ID", duration=2000)
        if amount is None:
            return rx.toast.error("充值金额必须大于 0，且最多两位小数", duration=2500)

        now = datetime.now()
        next_id = max((int(item["id"]) for item in self.deposits), default=0) + 1
        amount_value = float(amount)
        now_text = now.strftime("%Y-%m-%d %H:%M")

        new_record = {
            "id": next_id,
            "deposit_no": f"DEP{now:%Y%m%d%H%M%S}",
            "user": user_text,
            "user_id": 0,
            "bot": "主站 Bot",
            "amount": amount_value,
            "actual_amount": amount_value,
            "method": "手动充值",
            "to_address": "-",
            "tx_hash": None,
            "status": "completed",
            "created_at": now_text,
            "completed_at": now_text,
            "remark": remark,
        }

        self.deposits = [new_record, *self.deposits]

        updated_wallets: List[Dict[str, Any]] = []
        for wallet in self.wallets:
            next_wallet = dict(wallet)
            if int(next_wallet.get("id", 0)) == 1:
                next_wallet["balance"] = round(float(next_wallet.get("balance", 0)) + amount_value, 2)
                next_wallet["total_received"] = round(
                    float(next_wallet.get("total_received", 0)) + amount_value, 2
                )
            updated_wallets.append(next_wallet)
        self.wallets = updated_wallets

        self.close_manual_deposit_modal()
        return rx.toast.success("手动充值已入账", duration=2200)

    @rx.var
    def status_options(self) -> List[str]:
        return list(STATUS_LABEL_TO_CODE.keys())

    @rx.var
    def filtered_deposits(self) -> List[Dict[str, Any]]:
        items = list(self.deposits)

        query = self.search_query.strip().lower()
        if query:
            items = [
                item
                for item in items
                if query in str(item.get("deposit_no", "")).lower()
                or query in str(item.get("user", "")).lower()
                or query in str(item.get("bot", "")).lower()
            ]

        status_code = STATUS_LABEL_TO_CODE.get(self.filter_status, "")
        if status_code:
            items = [item for item in items if item.get("status") == status_code]

        return sorted(
            items,
            key=lambda item: str(item.get("created_at", "")),
            reverse=True,
        )

    @rx.var
    def total_deposits(self) -> int:
        return len(self.deposits)

    @rx.var
    def completed_deposits(self) -> int:
        return sum(1 for item in self.deposits if item.get("status") == "completed")

    @rx.var
    def pending_deposits(self) -> int:
        return sum(1 for item in self.deposits if item.get("status") == "confirming")

    @rx.var
    def total_deposit_amount(self) -> float:
        return round(
            sum(float(item.get("amount", 0)) for item in self.deposits if item.get("status") == "completed"),
            2,
        )

    @rx.var
    def today_deposits(self) -> float:
        today = datetime.now().strftime("%Y-%m-%d")
        return round(
            sum(
                float(item.get("amount", 0))
                for item in self.deposits
                if item.get("status") == "completed" and str(item.get("created_at", "")).startswith(today)
            ),
            2,
        )

    @rx.var
    def total_balance(self) -> float:
        return round(sum(float(wallet.get("balance", 0)) for wallet in self.wallets), 2)
