"""订单管理状态"""

import reflex as rx
from typing import List, Dict, Any, Optional
from pydantic import BaseModel
from datetime import datetime, timedelta
from pathlib import Path
import uuid
import csv
import time
import asyncio

from services.order_export import (
    EXPORT_CSV_HEADERS,
    build_export_filename,
    estimate_mock_total_records,
    iter_mock_order_chunks,
    sanitize_csv_value,
    validate_export_params,
)



class OrderItem(BaseModel):
    """订单商品详情"""
    name: str  # 库名称
    category: str  # 库分类
    merchant: str  # 商家
    quantity: int  # 数量
    unit_price: float  # 单价
    subtotal: float  # 小计


class Order(BaseModel):
    """订单数据模型"""
    id: int
    order_no: str
    user: str  # 用户显示名
    user_id: int
    telegram_id: str  # Telegram ID
    bot: str  # Bot 名称
    bot_id: int
    items: List[OrderItem]
    item_count: int  # 商品总数
    amount: float  # 总金额
    status: str  # completed, pending, refunded, cancelled
    created_at: str
    completed_at: Optional[str] = None
    refund_reason: Optional[str] = None


class OrderState(rx.State):
    """订单管理状态"""
    
    # 可用的 Bot 列表 (模拟数据，实际应从 BotState 获取)
    export_click_debounce_seconds: float = 2.0
    export_mock_chunk_size: int = 1000

    available_bots: List[Dict[str, Any]] = [
        {"id": 1, "name": "主站 Bot"},
        {"id": 2, "name": "代理A Bot"},
        {"id": 3, "name": "代理B Bot"},
    ]
    
    # 订单列表
    orders: List[Order] = [
        Order(
            id=1,
            order_no="ORD20240208001",
            user="Alice (@user_alice)",
            user_id=1,
            telegram_id="123456789",
            bot="主站 Bot",
            bot_id=1,
            items=[
                OrderItem(name="US-VISA-Premium", category="全资库-一手", merchant="平台自营", quantity=3, unit_price=5.50, subtotal=16.50),
                OrderItem(name="US-MC-Standard", category="全资库-二手", merchant="代理商A", quantity=2, unit_price=4.25, subtotal=8.50),
            ],
            item_count=5,
            amount=25.00,
            status="completed",
            created_at="2024-02-08 10:30",
            completed_at="2024-02-08 10:30",
        ),
        Order(
            id=2,
            order_no="ORD20240208002",
            user="Bob (@user_bob)",
            user_id=2,
            telegram_id="987654321",
            bot="代理A Bot",
            bot_id=2,
            items=[
                OrderItem(name="UK-VISA-Basic", category="裸资库", merchant="代理商B", quantity=3, unit_price=5.17, subtotal=15.50),
            ],
            item_count=3,
            amount=15.50,
            status="completed",
            created_at="2024-02-08 10:05",
            completed_at="2024-02-08 10:05",
        ),
        Order(
            id=3,
            order_no="ORD20240208003",
            user="User_456789012",
            user_id=4,
            telegram_id="456789012",
            bot="代理B Bot",
            bot_id=3,
            items=[
                OrderItem(name="CA-VISA-Sale", category="特价库", merchant="供应商C", quantity=8, unit_price=5.25, subtotal=42.00),
            ],
            item_count=8,
            amount=42.00,
            status="pending",
            created_at="2024-02-08 09:30",
            completed_at=None,
        ),
        Order(
            id=4,
            order_no="ORD20240207001",
            user="Charlie (@user_charlie)",
            user_id=3,
            telegram_id="321654987",
            bot="主站 Bot",
            bot_id=1,
            items=[
                OrderItem(name="AU-VISA-Premium", category="全资库-一手", merchant="平台自营", quantity=2, unit_price=4.00, subtotal=8.00),
            ],
            item_count=2,
            amount=8.00,
            status="refunded",
            created_at="2024-02-07 15:20",
            completed_at="2024-02-07 16:00",
            refund_reason="用户申请退款",
        ),
        Order(
            id=5,
            order_no="ORD20240207002",
            user="David (@user_david)",
            user_id=5,
            telegram_id="111222333",
            bot="代理A Bot",
            bot_id=2,
            items=[
                OrderItem(name="US-VISA-Premium", category="全资库-一手", merchant="平台自营", quantity=1, unit_price=5.50, subtotal=5.50),
            ],
            item_count=1,
            amount=5.50,
            status="cancelled",
            created_at="2024-02-07 14:00",
            completed_at=None,
        ),
    ]
    
    # 分页
    current_page: int = 1
    page_size: int = 20
    page_size_options: List[int] = [20, 30, 40, 50]
    
    # 排序
    sort_order: str = "desc"  # 创建时间排序: asc, desc
    
    # 弹窗控制
    show_detail_modal: bool = False
    show_refund_modal: bool = False
    show_export_modal: bool = False
    
    # 选中订单
    selected_order_id: Optional[int] = None
    selected_order: Optional[Order] = None
    
    # 退款
    refund_reason: str = ""
    
    # 筛选 - 添加默认选项
    search_query: str = ""
    filter_status: str = "全部状态"
    filter_bot: str = "全部 Bot"
    
    # 导出相关
    export_bot: str = ""
    export_date_from: str = ""
    export_date_to: str = ""
    is_exporting: bool = False
    export_progress: int = 0  # 导出进度 0-100
    export_task_id: str = ""  # 导出任务ID
    export_status: str = ""  # 导出状态: idle, preparing, fetching, processing, generating, completed, failed
    export_message: str = ""  # 导出状态消息
    export_file_url: str = ""  # 导出文件下载链接
    export_file_name: str = ""  # 导出文件名
    export_total_records: int = 0  # 导出总记录数
    export_processed_records: int = 0  # 已处理记录数
    last_export_click: float = 0  # 防抖用：上次点击时间戳
    
    # ==================== 筛选选项 ====================
    
    @rx.var
    def export_can_download(self) -> bool:
        return self.export_status == "completed" and bool(self.export_file_name)

    @rx.var
    def export_is_failed(self) -> bool:
        return self.export_status == "failed"

    @rx.var
    def export_record_progress_text(self) -> str:
        if self.export_total_records <= 0:
            return ""
        return f"{self.export_processed_records}/{self.export_total_records}"

    @rx.var
    def status_options(self) -> List[str]:
        """状态筛选选项"""
        return ["全部状态", "已完成", "待处理", "已退款", "已取消"]
    
    @rx.var
    def bot_filter_options(self) -> List[str]:
        """Bot 筛选选项 - 动态渲染"""
        options = ["全部 Bot"]
        for bot in self.available_bots:
            options.append(bot["name"])
        return options
    
    @rx.var
    def export_bot_options(self) -> List[str]:
        """导出 Bot 选项"""
        return [bot["name"] for bot in self.available_bots]
    
    # ==================== 筛选和搜索 ====================
    
    def set_search_query(self, value: str):
        self.search_query = value
        self.current_page = 1
    
    def set_filter_status(self, value: str):
        self.filter_status = value
        self.current_page = 1
    
    def set_filter_bot(self, value: str):
        self.filter_bot = value
        self.current_page = 1
    
    def set_sort_order(self, value: str):
        if value == "最新优先":
            self.sort_order = "desc"
        else:
            self.sort_order = "asc"
        self.current_page = 1
    
    # ==================== 分页处理 ====================
    
    def set_page_size(self, value: str):
        """设置每页显示数量"""
        try:
            size = int(value)
            if size < 20:
                size = 20
            elif size > 50:
                size = 50
            self.page_size = size
            self.current_page = 1
        except ValueError:
            self.page_size = 20
    
    def next_page(self):
        """下一页"""
        if self.current_page < self.total_pages:
            self.current_page += 1
    
    def prev_page(self):
        """上一页"""
        if self.current_page > 1:
            self.current_page -= 1
    
    def first_page(self):
        """第一页"""
        self.current_page = 1
    
    def last_page(self):
        """最后一页"""
        self.current_page = self.total_pages
    
    @rx.var
    def total_pages(self) -> int:
        """总页数"""
        total = len(self.filtered_orders)
        return max(1, (total + self.page_size - 1) // self.page_size)
    
    @rx.var
    def filtered_orders(self) -> List[Order]:
        """筛选后的订单列表"""
        items = self.orders
        
        # 搜索过滤 (订单号或用户)
        if self.search_query:
            query = self.search_query.lower()
            items = [
                order for order in items
                if query in order.order_no.lower() or query in order.user.lower()
            ]
        
        # 状态筛选
        if self.filter_status and self.filter_status != "全部状态":
            status_map = {
                "已完成": "completed",
                "待处理": "pending",
                "已退款": "refunded",
                "已取消": "cancelled",
            }
            status = status_map.get(self.filter_status, "")
            if status:
                items = [order for order in items if order.status == status]
        
        # Bot 筛选
        if self.filter_bot and self.filter_bot != "全部 Bot":
            items = [order for order in items if order.bot == self.filter_bot]
        
        # 按创建时间排序
        items = sorted(
            items,
            key=lambda x: x.created_at,
            reverse=(self.sort_order == "desc")
        )
        
        return items
    
    @rx.var
    def paginated_orders(self) -> List[Order]:
        """分页后的订单列表"""
        start = (self.current_page - 1) * self.page_size
        end = start + self.page_size
        return self.filtered_orders[start:end]
    
    @rx.var
    def display_total(self) -> int:
        """显示的总数"""
        return len(self.filtered_orders)
    
    @rx.var
    def display_range(self) -> str:
        """当前显示范围"""
        total = len(self.filtered_orders)
        if total == 0:
            return "0 - 0"
        start = (self.current_page - 1) * self.page_size + 1
        end = min(self.current_page * self.page_size, total)
        return f"{start} - {end}"
    
    # ==================== 详情弹窗 ====================
    
    def open_detail_modal(self, order_id: int):
        """打开订单详情弹窗"""
        self.selected_order_id = order_id
        for order in self.orders:
            if order.id == order_id:
                self.selected_order = order
                break
        self.show_detail_modal = True
    
    def close_detail_modal(self):
        """关闭详情弹窗"""
        self.show_detail_modal = False
        self.selected_order_id = None
        self.selected_order = None
    
    def handle_detail_modal_change(self, is_open: bool):
        """处理详情弹窗状态变化"""
        if not is_open:
            self.close_detail_modal()
    
    # ==================== 退款弹窗 ====================
    
    def open_refund_modal(self, order_id: int):
        """打开退款弹窗"""
        self.selected_order_id = order_id
        for order in self.orders:
            if order.id == order_id:
                self.selected_order = order
                break
        self.refund_reason = ""
        self.show_refund_modal = True
    
    def close_refund_modal(self):
        """关闭退款弹窗"""
        self.show_refund_modal = False
        self.selected_order_id = None
        self.selected_order = None
        self.refund_reason = ""
    
    def handle_refund_modal_change(self, is_open: bool):
        """处理退款弹窗状态变化"""
        if not is_open:
            self.close_refund_modal()
    
    def set_refund_reason(self, value: str):
        self.refund_reason = value
    
    def process_refund(self):
        """处理退款"""
        if not self.selected_order_id:
            return rx.toast.error("未选择订单", duration=3000)
        
        if not self.refund_reason:
            return rx.toast.error("请输入退款原因", duration=3000)
        
        # 更新订单状态
        updated_orders = []
        for order in self.orders:
            if order.id == self.selected_order_id:
                updated_order = Order(
                    id=order.id,
                    order_no=order.order_no,
                    user=order.user,
                    user_id=order.user_id,
                    telegram_id=order.telegram_id,
                    bot=order.bot,
                    bot_id=order.bot_id,
                    items=order.items,
                    item_count=order.item_count,
                    amount=order.amount,
                    status="refunded",
                    created_at=order.created_at,
                    completed_at=datetime.now().strftime("%Y-%m-%d %H:%M"),
                    refund_reason=self.refund_reason,
                )
                updated_orders.append(updated_order)
            else:
                updated_orders.append(order)
        
        self.orders = updated_orders
        self.close_refund_modal()
        return rx.toast.success("退款处理成功", duration=3000)
    
    # ==================== 导出弹窗 ====================
    
    # ==================== ???? ====================

    # ==================== Export Modal ====================

    def open_export_modal(self):
        """Open export dialog."""
        self.show_export_modal = True
        if not self.export_date_from or not self.export_date_to:
            today = datetime.now()
            self.export_date_to = today.strftime("%Y-%m-%d")
            self.export_date_from = (today - timedelta(days=30)).strftime("%Y-%m-%d")

    def close_export_modal(self):
        """Close export dialog."""
        self.show_export_modal = False

    def handle_export_modal_change(self, is_open: bool):
        """Handle export dialog open state changes."""
        if not is_open:
            self.close_export_modal()

    def set_export_bot(self, value: str):
        self.export_bot = value

    def set_export_date_from(self, value: str):
        self.export_date_from = value

    def set_export_date_to(self, value: str):
        self.export_date_to = value

    def export_orders(self):
        """Create export task and process it in background."""
        now = time.time()
        if now - self.last_export_click < self.export_click_debounce_seconds:
            return rx.toast.warning("Please wait before clicking again", duration=2000)

        self.last_export_click = now

        if self.is_exporting:
            return rx.toast.info("An export task is already running", duration=2500)

        try:
            validate_export_params(
                bot_name=self.export_bot,
                date_from=self.export_date_from,
                date_to=self.export_date_to,
            )
        except ValueError as exc:
            return rx.toast.error(f"Invalid export parameters: {str(exc)}", duration=3000)

        self.is_exporting = True
        self.export_progress = 0
        self.export_status = "preparing"
        self.export_message = "Task created, preparing export..."
        self.export_file_url = ""
        self.export_file_name = ""
        self.export_total_records = 0
        self.export_processed_records = 0
        self.export_task_id = uuid.uuid4().hex

        return [
            rx.toast.info("Export started, please wait", duration=2500),
            type(self).run_export_task,
        ]

    @rx.event(background=True)
    async def run_export_task(self):
        """Simulate backend data stream and write CSV continuously."""
        async with self:
            task_id = self.export_task_id
            export_bot = self.export_bot
            export_date_from = self.export_date_from
            export_date_to = self.export_date_to
            self.export_status = "fetching"
            self.export_message = "Requesting backend export stream..."

        try:
            params = validate_export_params(
                bot_name=export_bot,
                date_from=export_date_from,
                date_to=export_date_to,
            )
            total_records = estimate_mock_total_records(
                date_from=params.date_from,
                date_to=params.date_to,
            )

            exports_dir = Path("uploaded_files") / "exports"
            exports_dir.mkdir(parents=True, exist_ok=True)
            file_name = build_export_filename(params.bot_name)
            file_path = exports_dir / file_name

            async with self:
                if self.export_task_id != task_id:
                    return
                self.export_total_records = total_records
                self.export_status = "processing"
                self.export_message = "Processing records and writing file..."

            processed_records = 0
            with file_path.open("w", encoding="utf-8-sig", newline="") as csv_file:
                writer = csv.DictWriter(csv_file, fieldnames=EXPORT_CSV_HEADERS)
                writer.writeheader()

                async for chunk in iter_mock_order_chunks(
                    params=params,
                    total_records=total_records,
                    chunk_size=self.export_mock_chunk_size,
                ):
                    async with self:
                        if self.export_task_id != task_id:
                            return

                    for row in chunk:
                        writer.writerow(
                            {
                                field: sanitize_csv_value(row.get(field, ""))
                                for field in EXPORT_CSV_HEADERS
                            }
                        )

                    processed_records += len(chunk)
                    progress = int(processed_records * 100 / max(total_records, 1))

                    async with self:
                        if self.export_task_id != task_id:
                            return
                        self.export_processed_records = processed_records
                        self.export_progress = min(progress, 99)
                        self.export_message = (
                            f"Processed {processed_records}/{total_records} orders"
                        )

            async with self:
                if self.export_task_id != task_id:
                    return
                self.is_exporting = False
                self.export_status = "completed"
                self.export_progress = 100
                self.export_file_name = file_name
                self.export_file_url = str(file_path)
                self.export_message = "Export completed. Click download."

            return rx.toast.success(
                f"Export completed: {total_records} records",
                duration=4000,
            )
        except Exception as exc:
            async with self:
                if self.export_task_id != task_id:
                    return
                self.is_exporting = False
                self.export_status = "failed"
                self.export_message = f"Export failed: {str(exc)}"
                self.export_progress = 0

            return rx.toast.error(f"Export failed: {str(exc)}", duration=5000)

    def download_export_file(self):
        """Download generated export file."""
        if self.is_exporting:
            return rx.toast.info("Export is still running", duration=2000)

        if not self.export_file_url or not self.export_file_name:
            return rx.toast.error("No downloadable file available", duration=2500)

        file_path = Path(self.export_file_url)
        exports_root = (Path("uploaded_files") / "exports").resolve()

        try:
            resolved = file_path.resolve()
        except Exception:
            return rx.toast.error("Invalid export file path", duration=2500)

        if exports_root not in resolved.parents:
            return rx.toast.error("File access denied", duration=2500)

        if not resolved.exists() or not resolved.is_file():
            return rx.toast.error("Export file missing, please re-export", duration=2500)

        file_data = resolved.read_bytes()
        return [
            rx.download(
                data=file_data,
                filename=self.export_file_name,
                mime_type="text/csv;charset=utf-8",
            ),
            type(self).cleanup_export_modal_after_download,
        ]

    @rx.event(background=True)
    async def cleanup_export_modal_after_download(self):
        """Close export modal shortly after download is triggered."""
        await asyncio.sleep(0.2)
        async with self:
            self.show_export_modal = False

    # ==================== Refresh Orders ====================

    def refresh_order(self, order_id: int):
        """Refresh a single order status."""
        return rx.toast.info(f"Order #{order_id} refreshed", duration=2000)

    def refresh_list(self):
        """Refresh order list."""
        return rx.toast.info("Order list refreshed", duration=2000)

    # ==================== Metrics ====================

    @rx.var
    def total_orders(self) -> int:
        return len(self.orders)

    @rx.var
    def completed_orders(self) -> int:
        return sum(1 for o in self.orders if o.status == "completed")

    @rx.var
    def total_revenue(self) -> float:
        return sum(o.amount for o in self.orders if o.status == "completed")

    @rx.var
    def pending_orders(self) -> int:
        return sum(1 for o in self.orders if o.status == "pending")

    # ==================== ?????? ====================

    @rx.var
    def selected_order_no(self) -> str:
        if self.selected_order:
            return self.selected_order.order_no
        return ""

    @rx.var
    def selected_order_user(self) -> str:
        if self.selected_order:
            return self.selected_order.user
        return ""

    @rx.var
    def selected_order_telegram_id(self) -> str:
        if self.selected_order:
            return self.selected_order.telegram_id
        return ""

    @rx.var
    def selected_order_bot(self) -> str:
        if self.selected_order:
            return self.selected_order.bot
        return ""

    @rx.var
    def selected_order_amount(self) -> float:
        if self.selected_order:
            return self.selected_order.amount
        return 0.0

    @rx.var
    def selected_order_status(self) -> str:
        if self.selected_order:
            return self.selected_order.status
        return ""

    @rx.var
    def selected_order_created_at(self) -> str:
        if self.selected_order:
            return self.selected_order.created_at
        return ""

    @rx.var
    def selected_order_items(self) -> List[OrderItem]:
        if self.selected_order:
            return self.selected_order.items
        return []
