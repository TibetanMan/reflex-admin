"""个人资料页面"""

import reflex as rx
from ..templates.template import template, page_header
from ..styles import card_style, COLORS


@template
def profile() -> rx.Component:
    return rx.vstack(
        page_header(title="个人资料", subtitle="查看和编辑您的账户信息"),
        rx.grid(
            # 个人信息卡片
            rx.box(
                rx.vstack(
                    rx.avatar(fallback="A", size="7", radius="full"),
                    rx.heading("管理员", size="5"),
                    rx.text("admin@example.com", color="var(--gray-9)"),
                    rx.button("编辑资料", variant="outline", margin_top="16px"),
                    spacing="3",
                    align="center",
                    width="100%",
                ),
                **card_style,
                text_align="center",
            ),
            # 账户信息
            rx.box(
                rx.vstack(
                    rx.heading("账户信息", size="4"),
                    rx.divider(),
                    rx.hstack(rx.text("用户名:", font_weight="500"), rx.text("admin")),
                    rx.hstack(rx.text("角色:", font_weight="500"), rx.text("超级管理员")),
                    rx.hstack(rx.text("注册时间:", font_weight="500"), rx.text("2024-01-01")),
                    rx.hstack(rx.text("最后登录:", font_weight="500"), rx.text("2024-02-07")),
                    spacing="3",
                    align="start",
                    width="100%",
                ),
                **card_style,
            ),
            columns="2",
            spacing="6",
            width="100%",
        ),
        width="100%",
        spacing="6",
        align="start",
    )
