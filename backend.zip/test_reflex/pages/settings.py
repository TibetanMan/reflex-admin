"""系统设置页面"""

import reflex as rx
from ..templates.template import template, page_header
from ..styles import card_style, COLORS


class SettingsState(rx.State):
    notifications_enabled: bool = True
    email_updates: bool = False
    
    def toggle_notifications(self, value: bool):
        self.notifications_enabled = value
    
    def toggle_email(self, value: bool):
        self.email_updates = value


def setting_item(label: str, description: str, switch_state, on_change) -> rx.Component:
    return rx.hstack(
        rx.vstack(
            rx.text(label, font_weight="500"),
            rx.text(description, font_size="13px", color="var(--gray-9)"),
            spacing="1",
            align="start",
        ),
        rx.spacer(),
        rx.switch(checked=switch_state, on_change=on_change),
        width="100%",
        padding="12px 0",
        border_bottom="1px solid var(--gray-4)",
    )


@template
def settings() -> rx.Component:
    return rx.vstack(
        page_header(title="系统设置", subtitle="管理您的系统配置和偏好设置"),
        rx.box(
            rx.vstack(
                rx.heading("通知设置", size="4"),
                setting_item(
                    "推送通知", "接收重要事件的推送通知",
                    SettingsState.notifications_enabled,
                    SettingsState.toggle_notifications,
                ),
                setting_item(
                    "邮件更新", "接收系统更新和新闻邮件",
                    SettingsState.email_updates,
                    SettingsState.toggle_email,
                ),
                rx.button("保存设置", margin_top="24px"),
                spacing="2",
                align="start",
                width="100%",
            ),
            **card_style,
        ),
        width="100%",
        spacing="6",
        align="start",
    )
