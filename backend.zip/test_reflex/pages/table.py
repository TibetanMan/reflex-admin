"""数据表格页面"""

import reflex as rx

from ..templates.template import template, page_header
from ..styles import card_style, badge_success_style, badge_warning_style, badge_danger_style, COLORS


class TableState(rx.State):
    """表格状态"""
    search_query: str = ""
    selected_status: str = "全部"
    
    def set_search(self, value: str):
        self.search_query = value
    
    def set_status_filter(self, value: str):
        self.selected_status = value


# 静态用户数据
USERS_DATA = [
    {"id": 1, "name": "张三", "email": "zhangsan@example.com", "role": "管理员", "status": "活跃", "created_at": "2024-01-15"},
    {"id": 2, "name": "李四", "email": "lisi@example.com", "role": "编辑", "status": "活跃", "created_at": "2024-01-20"},
    {"id": 3, "name": "王五", "email": "wangwu@example.com", "role": "用户", "status": "待审核", "created_at": "2024-02-01"},
    {"id": 4, "name": "赵六", "email": "zhaoliu@example.com", "role": "用户", "status": "已禁用", "created_at": "2024-02-10"},
    {"id": 5, "name": "钱七", "email": "qianqi@example.com", "role": "编辑", "status": "活跃", "created_at": "2024-02-15"},
]


def status_badge(status: str) -> rx.Component:
    """状态徽章"""
    if status == "活跃":
        return rx.box(rx.text(status, font_size="12px"), style=badge_success_style)
    elif status == "待审核":
        return rx.box(rx.text(status, font_size="12px"), style=badge_warning_style)
    else:
        return rx.box(rx.text(status, font_size="12px"), style=badge_danger_style)


def table_row(name: str, email: str, role: str, status: str, created_at: str) -> rx.Component:
    """表格行"""
    return rx.table.row(
        rx.table.cell(rx.checkbox()),
        rx.table.cell(
            rx.hstack(
                rx.avatar(fallback=name[0], size="2", radius="full"),
                rx.vstack(
                    rx.text(name, font_weight="500"),
                    rx.text(email, font_size="12px", color="var(--gray-9)"),
                    spacing="0",
                    align="start",
                ),
                spacing="3",
            ),
        ),
        rx.table.cell(rx.text(role)),
        rx.table.cell(status_badge(status)),
        rx.table.cell(rx.text(created_at, color="var(--gray-9)")),
        rx.table.cell(
            rx.hstack(
                rx.icon_button(rx.icon("eye", size=16), variant="ghost", size="1"),
                rx.icon_button(rx.icon("pencil", size=16), variant="ghost", size="1"),
                rx.icon_button(rx.icon("trash-2", size=16), variant="ghost", size="1", color_scheme="red"),
                spacing="2",
            ),
        ),
        _hover={"background": "var(--gray-2)"},
    )


def users_table() -> rx.Component:
    """用户表格"""
    return rx.table.root(
        rx.table.header(
            rx.table.row(
                rx.table.column_header_cell(rx.checkbox(), width="40px"),
                rx.table.column_header_cell("用户"),
                rx.table.column_header_cell("角色"),
                rx.table.column_header_cell("状态"),
                rx.table.column_header_cell("创建时间"),
                rx.table.column_header_cell("操作", width="120px"),
            ),
        ),
        rx.table.body(
            *[table_row(u["name"], u["email"], u["role"], u["status"], u["created_at"]) for u in USERS_DATA],
        ),
        width="100%",
    )


@template
def table_page() -> rx.Component:
    """数据表格页面"""
    return rx.vstack(
        page_header(
            title="用户管理",
            subtitle="管理系统中的所有用户账户",
            actions=[
                rx.button(rx.icon("upload", size=16), "导入", variant="outline"),
                rx.button(rx.icon("download", size=16), "导出", variant="outline"),
                rx.button(
                    rx.icon("plus", size=16),
                    "添加用户",
                    background=f"linear-gradient(135deg, {COLORS['primary']}, {COLORS['secondary']})",
                ),
            ],
        ),
        rx.box(
            rx.vstack(
                rx.hstack(
                    rx.hstack(
                        rx.icon("search", size=18, color="var(--gray-9)"),
                        rx.input(
                            placeholder="搜索用户...",
                            value=TableState.search_query,
                            on_change=TableState.set_search,
                            variant="soft",
                            style={"width": "250px"},
                        ),
                        background="var(--gray-2)",
                        padding="4px 12px",
                        border_radius="8px",
                        align="center",
                    ),
                    rx.spacer(),
                    rx.hstack(
                        rx.select(["全部", "活跃", "待审核", "已禁用"], default_value="全部", on_change=TableState.set_status_filter),
                        rx.select(["全部角色", "管理员", "编辑", "用户"], default_value="全部角色"),
                        spacing="3",
                    ),
                    width="100%",
                    padding="16px 0",
                ),
                users_table(),
                rx.hstack(
                    rx.text(f"显示 1-5 条，共 5 条", font_size="14px", color="var(--gray-9)"),
                    rx.spacer(),
                    rx.hstack(
                        rx.icon_button(rx.icon("chevron-left", size=16), variant="outline", size="2"),
                        rx.button("1", variant="solid", size="2"),
                        rx.icon_button(rx.icon("chevron-right", size=16), variant="outline", size="2"),
                        spacing="2",
                    ),
                    width="100%",
                    padding="16px 0",
                ),
                width="100%",
                spacing="0",
            ),
            **card_style,
        ),
        width="100%",
        spacing="6",
        align="start",
    )
