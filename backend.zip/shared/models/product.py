"""商品/库存模型"""

from sqlmodel import SQLModel, Field, Relationship
from typing import Optional, TYPE_CHECKING
from datetime import datetime
from enum import Enum

if TYPE_CHECKING:
    from .category import Category
    from .merchant import Merchant


class ProductStatus(str, Enum):
    """商品状态"""
    AVAILABLE = "available"  # 可售
    SOLD = "sold"           # 已售
    LOCKED = "locked"       # 锁定中
    DEAD = "dead"           # 死卡/无效
    REFUNDED = "refunded"   # 已退款


class ProductItem(SQLModel, table=True):
    """商品/库存表 - 每一行数据代表一个可售商品"""
    
    __tablename__ = "product_items"
    
    id: Optional[int] = Field(default=None, primary_key=True)
    
    # 核心数据
    raw_data: str = Field(description="原始数据行 (加密存储)")
    data_hash: str = Field(unique=True, index=True, description="数据哈希 (用于去重)")
    
    # BIN 信息
    bin_number: str = Field(index=True, description="BIN 号")
    
    # 分类
    category_id: int = Field(foreign_key="categories.id", description="所属分类")
    country_code: str = Field(index=True, description="国家代码")
    
    # 供货商
    supplier_id: Optional[int] = Field(
        default=None,
        foreign_key="merchants.id",
        description="供货商 ID"
    )
    
    # 价格
    cost_price: float = Field(default=0.0, description="成本价")
    selling_price: float = Field(description="销售价格")
    
    # 状态
    status: ProductStatus = Field(default=ProductStatus.AVAILABLE, description="状态")
    
    # 售出信息
    sold_to_user_id: Optional[int] = Field(default=None, description="购买用户 ID")
    sold_to_bot_id: Optional[int] = Field(default=None, description="购买所在 Bot ID")
    sold_at: Optional[datetime] = Field(default=None, description="售出时间")
    sold_price: Optional[float] = Field(default=None, description="实际售价")
    
    # 锁定信息
    locked_by_user_id: Optional[int] = Field(default=None)
    locked_at: Optional[datetime] = Field(default=None)
    lock_expires_at: Optional[datetime] = Field(default=None)
    
    # 时间戳
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
    
    # 关联关系
    category: Optional["Category"] = Relationship(back_populates="products")
    supplier: Optional["Merchant"] = Relationship(back_populates="products")
    
    @property
    def is_available(self) -> bool:
        """是否可售"""
        return self.status == ProductStatus.AVAILABLE
    
    @property
    def is_sold(self) -> bool:
        """是否已售"""
        return self.status == ProductStatus.SOLD
    
    @property
    def masked_data(self) -> str:
        """脱敏数据（用于显示）"""
        # 只显示部分内容
        if len(self.raw_data) > 20:
            return f"{self.raw_data[:8]}****{self.raw_data[-4:]}"
        return "****"
