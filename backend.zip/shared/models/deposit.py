"""充值记录模型"""

from sqlmodel import SQLModel, Field, Relationship
from typing import Optional, TYPE_CHECKING
from datetime import datetime
from enum import Enum

if TYPE_CHECKING:
    from .user import User


class DepositStatus(str, Enum):
    """充值状态"""
    PENDING = "pending"      # 等待确认
    CONFIRMING = "confirming"  # 确认中
    COMPLETED = "completed"  # 已完成
    FAILED = "failed"       # 失败
    EXPIRED = "expired"     # 已过期


class DepositMethod(str, Enum):
    """充值方式"""
    USDT_TRC20 = "usdt_trc20"
    USDT_ERC20 = "usdt_erc20"
    MANUAL = "manual"  # 手动充值


class Deposit(SQLModel, table=True):
    """充值记录表"""
    
    __tablename__ = "deposits"
    
    id: Optional[int] = Field(default=None, primary_key=True)
    deposit_no: str = Field(unique=True, index=True, description="充值单号")
    
    # 用户
    user_id: int = Field(foreign_key="users.id", description="用户 ID")
    bot_id: int = Field(description="充值所在 Bot ID")
    
    # 金额
    amount: float = Field(description="充值金额 (USDT)")
    actual_amount: float = Field(default=0.0, description="实际到账金额")
    
    # 支付方式
    method: DepositMethod = Field(default=DepositMethod.USDT_TRC20, description="充值方式")
    
    # 区块链信息
    to_address: str = Field(description="收款地址")
    from_address: Optional[str] = Field(default=None, description="付款地址")
    tx_hash: Optional[str] = Field(default=None, unique=True, description="交易哈希")
    block_number: Optional[int] = Field(default=None, description="区块号")
    confirmations: int = Field(default=0, description="确认数")
    
    # 状态
    status: DepositStatus = Field(default=DepositStatus.PENDING, description="状态")
    
    # 手动操作 (手动充值时使用)
    operator_id: Optional[int] = Field(default=None, description="操作员 ID")
    operator_remark: Optional[str] = Field(default=None, description="操作备注")
    
    # 时间戳
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
    completed_at: Optional[datetime] = Field(default=None, description="完成时间")
    expires_at: Optional[datetime] = Field(default=None, description="过期时间")
    
    # 关联关系
    user: Optional["User"] = Relationship(back_populates="deposits")
    
    @property
    def is_completed(self) -> bool:
        """是否已完成"""
        return self.status == DepositStatus.COMPLETED
    
    @property
    def is_pending(self) -> bool:
        """是否待确认"""
        return self.status in [DepositStatus.PENDING, DepositStatus.CONFIRMING]
