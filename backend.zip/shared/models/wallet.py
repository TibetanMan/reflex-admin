"""钱包地址模型"""

from sqlmodel import SQLModel, Field
from typing import Optional
from datetime import datetime
from enum import Enum


class WalletStatus(str, Enum):
    """钱包状态"""
    ACTIVE = "active"      # 活跃监听中
    INACTIVE = "inactive"  # 已停止监听
    FULL = "full"         # 已满 (达到交易上限)


class WalletAddress(SQLModel, table=True):
    """钱包地址表 - 用于 USDT 收款监听"""
    
    __tablename__ = "wallet_addresses"
    
    id: Optional[int] = Field(default=None, primary_key=True)
    
    # 地址信息
    address: str = Field(unique=True, index=True, description="钱包地址")
    private_key: Optional[str] = Field(default=None, description="私钥 (加密存储，可选)")
    
    # 归属
    bot_id: Optional[int] = Field(default=None, description="归属 Bot ID")
    agent_id: Optional[int] = Field(default=None, description="归属代理 ID")
    is_platform: bool = Field(default=False, description="是否是平台地址")
    
    # 余额
    balance: float = Field(default=0.0, description="当前余额")
    total_received: float = Field(default=0.0, description="累计收款")
    
    # 监听配置
    status: WalletStatus = Field(default=WalletStatus.ACTIVE, description="状态")
    last_checked_at: Optional[datetime] = Field(default=None, description="最后检查时间")
    last_tx_at: Optional[datetime] = Field(default=None, description="最后交易时间")
    
    # 标签/备注
    label: Optional[str] = Field(default=None, description="标签")
    remark: Optional[str] = Field(default=None, description="备注")
    
    # 时间戳
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
    
    @property
    def is_active(self) -> bool:
        """是否活跃"""
        return self.status == WalletStatus.ACTIVE
    
    @property
    def masked_address(self) -> str:
        """脱敏地址"""
        if len(self.address) > 20:
            return f"{self.address[:8]}...{self.address[-6:]}"
        return self.address
