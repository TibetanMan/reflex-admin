"""购物车模型"""

from sqlmodel import SQLModel, Field, Relationship
from typing import Optional, TYPE_CHECKING
from datetime import datetime

if TYPE_CHECKING:
    from .user import User


class CartItem(SQLModel, table=True):
    """购物车项表"""
    
    __tablename__ = "cart_items"
    
    id: Optional[int] = Field(default=None, primary_key=True)
    
    # 用户
    user_id: int = Field(foreign_key="users.id", index=True, description="用户 ID")
    
    # 购买意向 (用户想买的类型/分类)
    category_id: int = Field(description="分类 ID")
    category_query: str = Field(description="查询条件，如 'US_VISA_PLATINUM'")
    
    # 数量
    quantity: int = Field(default=1, description="数量")
    
    # 预估价格
    unit_price: float = Field(description="单价")
    subtotal: float = Field(description="小计")
    
    # 时间戳
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
    expires_at: Optional[datetime] = Field(default=None, description="过期时间")
    
    # 关联关系
    user: Optional["User"] = Relationship(back_populates="cart_items")
    
    @property
    def is_expired(self) -> bool:
        """是否已过期"""
        if self.expires_at is None:
            return False
        return datetime.utcnow() > self.expires_at
