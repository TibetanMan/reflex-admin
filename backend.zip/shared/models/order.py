"""订单模型"""

from sqlmodel import SQLModel, Field, Relationship
from typing import Optional, List, TYPE_CHECKING
from datetime import datetime
from enum import Enum

if TYPE_CHECKING:
    from .user import User


class OrderStatus(str, Enum):
    """订单状态"""
    PENDING = "pending"      # 待支付
    PAID = "paid"           # 已支付
    COMPLETED = "completed"  # 已完成
    REFUNDED = "refunded"   # 已退款
    CANCELLED = "cancelled"  # 已取消


class Order(SQLModel, table=True):
    """订单表"""
    
    __tablename__ = "orders"
    
    id: Optional[int] = Field(default=None, primary_key=True)
    order_no: str = Field(unique=True, index=True, description="订单号")
    
    # 用户信息
    user_id: int = Field(foreign_key="users.id", description="用户 ID")
    bot_id: int = Field(description="下单所在 Bot ID")
    
    # 金额
    total_amount: float = Field(description="订单总额")
    paid_amount: float = Field(default=0.0, description="实付金额")
    
    # 商品信息
    items_count: int = Field(default=0, description="商品数量")
    
    # 状态
    status: OrderStatus = Field(default=OrderStatus.PENDING, description="订单状态")
    
    # 分润 (订单完成时计算)
    platform_profit: float = Field(default=0.0, description="平台利润")
    agent_profit: float = Field(default=0.0, description="代理利润")
    supplier_profit: float = Field(default=0.0, description="供货商利润")
    
    # 备注
    remark: Optional[str] = Field(default=None, description="备注")
    refund_reason: Optional[str] = Field(default=None, description="退款原因")
    
    # 时间戳
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)
    paid_at: Optional[datetime] = Field(default=None, description="支付时间")
    completed_at: Optional[datetime] = Field(default=None, description="完成时间")
    refunded_at: Optional[datetime] = Field(default=None, description="退款时间")
    
    # 关联关系
    user: Optional["User"] = Relationship(back_populates="orders")
    items: List["OrderItem"] = Relationship(back_populates="order")
    
    @property
    def is_paid(self) -> bool:
        """是否已支付"""
        return self.status in [OrderStatus.PAID, OrderStatus.COMPLETED]
    
    @property
    def can_refund(self) -> bool:
        """是否可退款"""
        return self.status in [OrderStatus.PAID, OrderStatus.COMPLETED]


class OrderItem(SQLModel, table=True):
    """订单项表"""
    
    __tablename__ = "order_items"
    
    id: Optional[int] = Field(default=None, primary_key=True)
    
    # 关联
    order_id: int = Field(foreign_key="orders.id", description="订单 ID")
    product_id: int = Field(description="商品 ID")
    
    # 快照信息 (下单时保存)
    product_data: str = Field(description="商品数据 (加密)")
    category_name: str = Field(description="分类名称")
    bin_number: str = Field(description="BIN 号")
    country_code: str = Field(description="国家代码")
    
    # 价格
    unit_price: float = Field(description="单价")
    quantity: int = Field(default=1, description="数量")
    subtotal: float = Field(description="小计")
    
    # 时间戳
    created_at: datetime = Field(default_factory=datetime.utcnow)
    
    # 关联关系
    order: Optional["Order"] = Relationship(back_populates="items")
