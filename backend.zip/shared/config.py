"""全局配置"""

from pydantic_settings import BaseSettings
from functools import lru_cache
from typing import Optional


class Settings(BaseSettings):
    """应用配置"""
    
    # 应用信息
    app_name: str = "Digital Goods Platform"
    app_version: str = "0.1.0"
    debug: bool = True
    
    # 数据库配置
    database_url: str = "postgresql+asyncpg://postgres:postgres@localhost:5432/digital_goods"
    database_echo: bool = False
    
    # Redis 配置
    redis_url: str = "redis://localhost:6379/0"
    
    # Telegram Bot 配置
    bot_token: Optional[str] = None
    
    # USDT 支付配置
    trongrid_api_key: Optional[str] = None
    usdt_contract_address: str = "TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t"  # TRC20 USDT
    
    # 安全配置
    secret_key: str = "your-secret-key-change-in-production"
    access_token_expire_minutes: int = 60 * 24  # 24 hours
    
    # 分页配置
    default_page_size: int = 20
    max_page_size: int = 100
    
    class Config:
        env_file = ".env"
        env_file_encoding = "utf-8"
        case_sensitive = False


@lru_cache()
def get_settings() -> Settings:
    """获取配置单例"""
    return Settings()


settings = get_settings()
