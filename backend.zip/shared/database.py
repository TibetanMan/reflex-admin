"""数据库连接与会话管理"""

from sqlmodel import SQLModel, create_engine, Session
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import sessionmaker
from contextlib import contextmanager, asynccontextmanager
from typing import Generator, AsyncGenerator

from .config import settings


# 同步引擎 (用于 Reflex 后台)
sync_engine = create_engine(
    settings.database_url.replace("+asyncpg", ""),
    echo=settings.database_echo,
    pool_pre_ping=True,
    pool_size=5,
    max_overflow=10,
)

# 异步引擎 (用于 Bot)
async_engine = create_async_engine(
    settings.database_url,
    echo=settings.database_echo,
    pool_pre_ping=True,
    pool_size=5,
    max_overflow=10,
)

# 异步会话工厂
async_session_factory = sessionmaker(
    async_engine,
    class_=AsyncSession,
    expire_on_commit=False,
)


def init_db():
    """初始化数据库，创建所有表"""
    # 导入所有模型以确保它们被注册
    from .models import (
        User, AdminUser, BotInstance, BinInfo, 
        Category, ProductItem, Order, OrderItem,
        CartItem, Deposit, WalletAddress, Agent, Merchant
    )
    SQLModel.metadata.create_all(sync_engine)


def drop_db():
    """删除所有表（仅用于测试）"""
    SQLModel.metadata.drop_all(sync_engine)


@contextmanager
def get_session() -> Generator[Session, None, None]:
    """获取同步数据库会话"""
    session = Session(sync_engine)
    try:
        yield session
        session.commit()
    except Exception:
        session.rollback()
        raise
    finally:
        session.close()


@asynccontextmanager
async def get_async_session() -> AsyncGenerator[AsyncSession, None]:
    """获取异步数据库会话"""
    async with async_session_factory() as session:
        try:
            yield session
            await session.commit()
        except Exception:
            await session.rollback()
            raise
        finally:
            await session.close()


# 用于 Reflex State 的简单会话获取
def get_db_session() -> Session:
    """获取数据库会话（用于 Reflex State）"""
    return Session(sync_engine)
