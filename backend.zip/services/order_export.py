"""Order export helpers for async streaming simulation."""

from __future__ import annotations

import asyncio
import re
from dataclasses import dataclass
from datetime import date, datetime, time, timedelta
from typing import Any, AsyncIterator


EXPORT_CSV_HEADERS = [
    "order_no",
    "bot_name",
    "username",
    "telegram_id",
    "item_count",
    "amount",
    "status",
    "created_at",
]

EXPORT_STATUS_VALUES = ("completed", "pending", "refunded", "cancelled")


@dataclass(frozen=True)
class ExportParams:
    """Validated export parameters."""

    bot_name: str
    date_from: date
    date_to: date


def validate_export_params(bot_name: str, date_from: str, date_to: str) -> ExportParams:
    """Validate and normalize export parameters."""
    normalized_bot_name = bot_name.strip()
    if not normalized_bot_name:
        raise ValueError("bot_name is required")

    try:
        start_date = datetime.strptime(date_from, "%Y-%m-%d").date()
        end_date = datetime.strptime(date_to, "%Y-%m-%d").date()
    except ValueError as exc:
        raise ValueError("date format must be YYYY-MM-DD") from exc

    if end_date < start_date:
        raise ValueError("date_to must be greater than or equal to date_from")

    return ExportParams(
        bot_name=normalized_bot_name,
        date_from=start_date,
        date_to=end_date,
    )


def estimate_mock_total_records(date_from: date, date_to: date) -> int:
    """Estimate export volume for simulation purposes."""
    days = (date_to - date_from).days + 1
    return max(100, min(days * 400, 50000))


def build_export_filename(bot_name: str, now: datetime | None = None) -> str:
    """Build a safe file name for a CSV export."""
    current_time = now or datetime.now()
    safe_bot = re.sub(r"[^a-zA-Z0-9]+", "_", bot_name.strip().lower()).strip("_")
    if not safe_bot:
        safe_bot = "bot"
    return f"orders_{safe_bot}_{current_time:%Y%m%d_%H%M%S}.csv"


def sanitize_csv_value(value: Any) -> str:
    """Prevent CSV formula injection by prefixing risky leading chars."""
    text = str(value)
    if text.startswith(("=", "+", "-", "@")):
        return f"'{text}"
    return text


async def iter_mock_order_chunks(
    params: ExportParams,
    total_records: int,
    chunk_size: int = 1000,
    sleep_seconds: float = 0.03,
) -> AsyncIterator[list[dict[str, Any]]]:
    """Yield mock order records in chunks to mimic backend streaming."""
    if total_records <= 0:
        return

    days = (params.date_to - params.date_from).days + 1
    chunk: list[dict[str, Any]] = []

    for index in range(total_records):
        day_offset = index % days
        created_date = params.date_from + timedelta(days=day_offset)
        created_at = datetime.combine(
            created_date,
            time(hour=index % 24, minute=(index * 7) % 60, second=(index * 11) % 60),
        )

        row = {
            "order_no": f"ORD{created_date:%Y%m%d}{index + 1:08d}",
            "bot_name": params.bot_name,
            "username": f"user_{100000 + (index % 900000)}",
            "telegram_id": str(100000000 + (index % 900000000)),
            "item_count": (index % 8) + 1,
            "amount": round(5 + ((index % 500) * 0.37), 2),
            "status": EXPORT_STATUS_VALUES[index % len(EXPORT_STATUS_VALUES)],
            "created_at": created_at.strftime("%Y-%m-%d %H:%M:%S"),
        }
        chunk.append(row)

        if len(chunk) >= chunk_size:
            yield chunk
            chunk = []
            if sleep_seconds > 0:
                await asyncio.sleep(sleep_seconds)

    if chunk:
        yield chunk

